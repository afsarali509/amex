-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 04, 2025 at 05:28 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `amex_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `admin_type` varchar(50) NOT NULL,
  `status` enum('A','I','D','B') NOT NULL,
  `token` varchar(512) DEFAULT NULL,
  `users_otp` int(11) DEFAULT NULL,
  `login_at` datetime DEFAULT NULL,
  `login_ip` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_ip` varchar(50) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_ip` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `phone`, `password`, `name`, `admin_type`, `status`, `token`, `users_otp`, `login_at`, `login_ip`, `created_at`, `created_ip`, `updated_at`, `updated_ip`) VALUES
(1, 'afsarali509', 'afsarali509@gmail.com', '7004477637', '25d55ad283aa400af464c76d713c07ad', 'Afsar Ali', 'Super Admin', 'A', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7InVzZXJJZCI6MSwidXNlclR5cGUiOiJTdXBlciBBZG1pbiIsImNyZWF0ZWRBdCI6IjIwMjUtMDctMDNUMTU6NDM6NDkuNDQ0WiJ9LCJpYXQiOjE3NTE1NTc0MjksImV4cCI6MTc4MzA5MzQyOSwiaXNzIjoiU3VwZXIgQWRtaW4ifQ.K_SH1aVyEAvdnd9OjM7eIvCFo9NNB3hbq8VOYVouLD0', 0, '2025-07-03 18:43:49', ':1', '2025-06-26 00:00:00', ':1', NULL, NULL),
(2, '', 'ali@gmail.com', '7004477637', '25d55ad283aa400af464c76d713c07ad', 'Ali Afsar', 'Sub Admin', 'A', NULL, NULL, '2025-07-02 21:03:34', NULL, '0000-00-00 00:00:00', NULL, NULL, '::1');

-- --------------------------------------------------------

--
-- Table structure for table `coins`
--

CREATE TABLE `coins` (
  `id` int(11) NOT NULL,
  `coin` varchar(255) NOT NULL,
  `symbol` varchar(255) NOT NULL,
  `coin_id` varchar(255) NOT NULL,
  `current_price` float DEFAULT NULL,
  `price_change_percentage_24h` varchar(255) DEFAULT NULL,
  `image` varchar(512) NOT NULL,
  `seq_order` int(11) NOT NULL DEFAULT 1,
  `status` enum('A','I') NOT NULL,
  `created_at` datetime NOT NULL,
  `created_ip` varchar(50) NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_ip` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `coins`
--

INSERT INTO `coins` (`id`, `coin`, `symbol`, `coin_id`, `current_price`, `price_change_percentage_24h`, `image`, `seq_order`, `status`, `created_at`, `created_ip`, `updated_at`, `updated_ip`) VALUES
(1, 'Bitcoin', 'btc', 'bitcoin', 109934, '0.45568', 'https://coin-images.coingecko.com/coins/images/1/large/bitcoin.png?1696501400', 1, 'A', '2025-07-01 20:02:17', '::1', '2025-07-03 23:44:47', ''),
(2, 'Ethereum', 'eth', 'ethereum', 2596.02, '-0.20249', 'https://coin-images.coingecko.com/coins/images/279/large/ethereum.png?1696501628', 1, 'A', '2025-07-02 21:44:39', '::1', '2025-07-03 23:44:47', '::1'),
(3, 'TRON', 'trx', 'tron', 0.285399, '0.85278', 'https://coin-images.coingecko.com/coins/images/1094/large/tron-logo.png?1696502193', 1, 'A', '2025-07-03 19:30:41', '::1', '2025-07-03 23:44:47', '::1'),
(4, 'Tether Gold', 'xaut', 'tether-gold', 3326.09, '-0.83247', 'https://coin-images.coingecko.com/coins/images/10481/large/Tether_Gold.png?1696510471', 1, 'A', '2025-07-03 19:39:46', '::1', '2025-07-03 23:44:47', '::1'),
(6, 'Crude Oil Brent', 'oil', 'crude-oil-brent', 69.69, NULL, 'https://coin-images.coingecko.com/coins/images/38103/large/oil.png?1716527227', 1, 'A', '2025-07-03 19:50:50', '::1', '2025-07-03 23:44:47', ''),
(7, 'Dogecoin', 'doge', 'dogecoin', 0.172611, '0.59871', 'https://coin-images.coingecko.com/coins/images/5/large/dogecoin.png?1696501409', 1, 'A', '2025-07-03 19:51:06', '::1', '2025-07-03 23:44:47', ''),
(8, 'Litecoin', 'ltc', 'litecoin', 89.73, '1.65744', 'https://coin-images.coingecko.com/coins/images/2/large/litecoin.png?1696501400', 1, 'A', '2025-07-03 19:51:24', '::1', '2025-07-03 23:44:47', ''),
(9, 'XRP', 'xrp', 'ripple', 2.28, '0.7158', 'https://coin-images.coingecko.com/coins/images/44/large/xrp-symbol-white-128.png?1696501442', 1, 'A', '2025-07-03 19:52:20', '::1', '2025-07-03 23:44:47', ''),
(10, 'Monero', 'xmr', 'monero', 318.05, '-2.40091', 'https://coin-images.coingecko.com/coins/images/69/large/monero_logo.png?1696501460', 1, 'A', '2025-07-03 19:52:36', '::1', '2025-07-03 23:44:47', ''),
(11, 'Ethereum Classic', 'etc', 'ethereum-classic', 17.03, '-0.75625', 'https://coin-images.coingecko.com/coins/images/453/large/ethereum-classic-logo.png?1696501717', 1, 'A', '2025-07-03 19:52:54', '::1', '2025-07-03 23:44:47', ''),
(12, 'Bitcoin Cash', 'bch', 'bitcoin-cash', 498.65, '-1.75262', 'https://coin-images.coingecko.com/coins/images/780/large/bitcoin-cash-circle.png?1696501932', 1, 'A', '2025-07-03 19:53:09', '::1', '2025-07-03 23:44:47', ''),
(13, 'EOS', 'eos', 'eos', 0.49711, '-0.71761', 'https://coin-images.coingecko.com/coins/images/738/large/CG_EOS_Icon.png?1731705232', 1, 'A', '2025-07-03 19:53:25', '::1', '2025-07-03 23:44:47', ''),
(14, 'Panda Coin', 'panda', 'panda-coin', 0.00000386, '-2.79309', 'https://coin-images.coingecko.com/coins/images/20500/large/panda.png?1696519907', 1, 'A', '2025-07-03 19:54:04', '::1', '2025-07-03 23:44:47', ''),
(15, 'Dash', 'dash', 'dash', 20.62, '0.86874', 'https://coin-images.coingecko.com/coins/images/19/large/dash-logo.png?1696501423', 1, 'A', '2025-07-03 19:54:19', '::1', '2025-07-03 23:44:47', ''),
(16, 'Ontology', 'ont', 'ontology', 0.126169, '-0.24303', 'https://coin-images.coingecko.com/coins/images/3447/large/ONT.png?1696504138', 1, 'A', '2025-07-03 19:54:32', '::1', '2025-07-03 23:44:47', ''),
(17, 'BNB', 'bnb', 'binancecoin', 662.37, '-0.29233', 'https://coin-images.coingecko.com/coins/images/825/large/bnb-icon2_2x.png?1696501970', 1, 'A', '2025-07-03 19:54:43', '::1', '2025-07-03 23:44:47', ''),
(18, 'IOTA', 'iota', 'iota', 0.16388, '-1.09406', 'https://coin-images.coingecko.com/coins/images/692/large/IOTA_Thumbnail_%281%29.png?1743772896', 1, 'A', '2025-07-03 19:54:54', '::1', '2025-07-03 23:44:47', ''),
(19, 'Polkadot', 'dot', 'polkadot', 3.56, '-0.75451', 'https://coin-images.coingecko.com/coins/images/12171/large/polkadot.png?1696512008', 1, 'A', '2025-07-03 19:55:07', '::1', '2025-07-03 23:44:47', '');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `id` int(11) NOT NULL,
  `coin_id` varchar(255) NOT NULL,
  `current_price` float NOT NULL,
  `amount` float NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_ip` varchar(50) NOT NULL,
  `updated_at` datetime DEFAULT current_timestamp(),
  `updated_ip` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`id`, `coin_id`, `current_price`, `amount`, `email`, `phone`, `type`, `status`, `remarks`, `created_at`, `created_ip`, `updated_at`, `updated_ip`) VALUES
(2, 'bitcoin', 109934, 10, 'afsarali509@gmail.com', '7654940266', 'Sell', 'Pending', NULL, '2025-07-04 06:15:09', '::1', '2025-07-04 08:45:09', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(512) NOT NULL,
  `status` enum('A','I','B','D') NOT NULL DEFAULT 'A',
  `token` varchar(512) DEFAULT NULL,
  `login_at` datetime DEFAULT NULL,
  `login_ip` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `created_ip` varchar(50) NOT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_ip` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `phone`, `email`, `password`, `status`, `token`, `login_at`, `login_ip`, `created_at`, `created_ip`, `updated_at`, `updated_ip`) VALUES
(13, 'Afsar', '7654940266', 'afsarali509@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'A', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7InVzZXJJZCI6MTMsInVzZXJUeXBlIjoiVXNlcnMiLCJjcmVhdGVkQXQiOiIyMDI1LTA3LTAzVDIxOjM2OjAyLjI4MloifSwiaWF0IjoxNzUxNTc4NTYyLCJleHAiOjE3ODMxMTQ1NjIsImlzcyI6IlVzZXJzIn0.wff9zH8IcqC2zwGvcdKVyXk83Jhzzi9fVn6YvlpwqUc', '2025-07-04 00:36:02', ':1', '2025-06-30 20:26:35', '::1', '2025-06-30 17:26:35', '::1'),
(14, 'Ali', '12345678', 'ali@gmail.com', '96e79218965eb72c92a549dd5a330112', 'A', NULL, NULL, NULL, '2025-07-02 21:35:13', '::1', '2025-07-02 18:35:13', '::1');

-- --------------------------------------------------------

--
-- Table structure for table `verifyotp`
--

CREATE TABLE `verifyotp` (
  `id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(10) DEFAULT NULL,
  `otp` int(11) NOT NULL,
  `duration` int(11) NOT NULL DEFAULT 10,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coins`
--
ALTER TABLE `coins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `verifyotp`
--
ALTER TABLE `verifyotp`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `coins`
--
ALTER TABLE `coins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `verifyotp`
--
ALTER TABLE `verifyotp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
