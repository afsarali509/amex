const { knex } = require('../../util/db');

// Insert a new admin
exports.insert = async (data, tblName) => {
  return await knex(tblName).insert(data);
}

// Update an admin by id
exports.update = async (options, tblName) => {
  try {
    const { condition, data } = options;
    // console.log()
     await knex(tblName).where(condition).update(data);
     return knex(tblName).where(condition).select();
  } catch (error) {
    console.log('error : ', error);
  }
}

//Delete from table
exports.delete = async (condition, tblName) => {
  return await knex(tblName).delete(condition);
}

// Select admin(s) by filter
exports.select = async (options, tblName) => {
  try {
    const {type='', condition={}, select="*", skip=0, limit=10} = options;
    const { $or = [], ...where } = condition;
    const query = knex(tblName);
    if (Object.keys(where).length) {
      query.where(where);
    }

    // Apply $or conditions
    if (Array.isArray($or) && $or.length > 0) {
      query.andWhere(function () {
        $or.forEach((orCond) => {
          this.orWhere(orCond);
        });
      });
    }
    if (type === 'count') {
      const [{ count }] = await query.count({ count: '*' });
      return parseInt(count, 10);
    } else if (type === 'single') {
      return await query.first(select);
    } else {
      return await query.select(select).offset(skip).limit(limit).orderBy('id','asc');
    }
  } catch (error) {
    
  }
}