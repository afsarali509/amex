const commonServices = require("../../services/commonServices");
const axios = require('axios');
exports.updateCoinValue = async function (req, res) {
try {
    const totalProcessData = [];
    const options = {
        condition : {status : "A"},
        select : ['coin_id'],
        skip : 0,
        limit : 100
    }
    const coinsData = await commonServices.select(options,'coins');
    const coin_id = coinsData.map((item)=>item.coin_id);
    const priceList = await getPriceList(coin_id?.join(','));
    if (priceList && priceList.length > 0) {
        await Promise.all(priceList.map(async (item) => {
            const updateParam = {
                condition: { coin_id: item?.id },
                data: {
                    coin: item?.name,
                    symbol: item?.symbol,
                    image: item?.image,
                    current_price: parseFloat(item?.current_price),
                    price_change_percentage_24h : item?.price_change_percentage_24h,
                    updated_at : new Date()
                }
            };
            const result = await commonServices.update(updateParam,'coins');
            totalProcessData.push(result?.id)
        }));
        return `${totalProcessData?.length} data updated`;
    } 

} catch (error) {
    console.log('error : ', error);
}
}

const getPriceList = async (ids = "") => {
    try {
        const url = `https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${ids}`;
        const response = await axios.get(url);
        return response?.data || [];
    } catch (error) {
        console.log('error:', error);
    }
};