const response = require('../../../../util/response');
const accountServices = require("../../../services/adminService");
const { createMD5Hash, checkMD5Password} = require("../../../../util/crypto");
const { generateToken } = require("../../../../util/authToken");
const {getIpAddress} = require("../../../../util/utility"); 
const moment = require('moment');
/*********************************************************************************
 * Function Name    :   List
 * Purpose          :   This function is used for get users list
 * Created By       :   Afsar Ali
 * Created Data     :   09-12-2024
 * Updated By       :   
 * Update Data      :
 * Remarks          :
 ********************************************************************************/
exports.login = async function (req, res) {
    try {
        const {email, password} = req.body;
        if(!email){
            return response.sendResponse(res, response.build("EMAIL_EMPTY", { }));
        } else if(!password){
            return response.sendResponse(res, response.build("PASSWORD_EMPTY", { }));
        } else{
            const where = {
                type : "single",
                condition : {
                    email : email
                },
                // select : { email : true, status : true }
                select : ['id', 'email', 'status', 'password']
            }
            const userData = await accountServices.selectAdmins(where);
            console.log('userData : ', userData);
            if(userData && userData.status === "A"){
                const hashedPassword = await createMD5Hash(password);
                console.log('hashedPassword : ', hashedPassword);
                console.log('userData?.password : ', userData?.password);
                if(hashedPassword === userData?.password){
                    // let code = Math.floor(100000 + Math.random() * 900000);
                    let code = 654321;
                    const updateOption = {
                        condition : {id : userData?.id},
                        data : {
                            users_otp : parseInt(code)
                        }
                    }
                    await accountServices.updateAdmin(updateOption);
                    return response.sendResponse(res, response.build("SUCCESS", { result : {} }));
                } else {
                    return response.sendResponse(res, response.build("INVALID_LOGIN_CREDENTIAL", { }));
                }
            } else if(userData && userData.status === "I"){
                return response.sendResponse(res, response.build("INACTIVE_ACCOUNT", {  }));
            } else if(userData && userData.status === "B"){
                return response.sendResponse(res, response.build("BLOCK_ACCOUNT", {  }));
            } else if(userData && userData.status === "D"){
                return response.sendResponse(res, response.build("DELETE_ACCOUNT", {  }));
            } else {
                return response.sendResponse(res, response.build("INVALID_LOGIN_CREDENTIAL", { }));
            }
            // if(userData && )
        }
    } catch (error) {
        console.log('error',error)
        return response.sendResponse(res, response.build('ERROR_SERVER_ERROR', { error }));
    }
}; //End of Function 

/*********************************************************************************
 * Function Name    :   verifyOTP
 * Purpose          :   This function is used for verify OTP
 * Created By       :   Afsar Ali
 * Created Data     :   28-06-2025
 * Updated By       :   
 * Update Data      :
 * Remarks          :
 ********************************************************************************/
exports.verifyOTP = async function (req, res) {
    try {
        const {email, otp} = req.body;
        if(!email){
            return response.sendResponse(res, response.build("EMAIL_EMPTY", { }));
        } else if(!otp){
            return response.sendResponse(res, response.build("OTP_EMPTY", { }));
        } else{
            const where = {
                type : "single",
                condition : {
                    email : email
                },
                // select : { email : true, status : true }
                select : ['id', 'email', 'status', 'users_otp']
            }
            const userData = await accountServices.selectAdmins(where);
            if(userData && userData.status === "A"){
                if(parseInt(otp) === userData?.users_otp){
                    const token = await generateToken(userData?.id, 
                        "Super Admin", 
                        "Super Admin", 
                        '365 days');
                    const updateOption = {
                        condition : {id : userData?.id},
                        data : {
                            token : token,
                            users_otp : "",
                            login_at : moment().format('YYYY-MM-DD HH:mm:ss'),
                            login_ip : ":1"
                        }
                    }
                    const result = await accountServices.updateAdmin(updateOption);
                    return response.sendResponse(res, response.build("SUCCESS", { result : result }));
                } else {
                    return response.sendResponse(res, response.build("INVALID_OTP", { }));
                }
            } else if(userData && userData.status === "I"){
                return response.sendResponse(res, response.build("INACTIVE_ACCOUNT", {  }));
            } else if(userData && userData.status === "B"){
                return response.sendResponse(res, response.build("BLOCK_ACCOUNT", {  }));
            } else {
                return response.sendResponse(res, response.build("DELETE_ACCOUNT", {  }));
            }
            // if(userData && )
        }
    } catch (error) {
        console.log('error',error)
        return response.sendResponse(res, response.build('ERROR_SERVER_ERROR', { error }));
    }
}; //End of Function 

/*********************************************************************************
 * Function Name    :   forgotPassword
 * Purpose          :   This function is used for get forgot password
 * Created By       :   Afsar Ali
 * Created Data     :   28-06-2025
 * Updated By       :   
 * Update Data      :
 * Remarks          :
 ********************************************************************************/
exports.forgotPassword = async function (req, res) {
    try {
        const {email} = req.body;
        if(!email){
            return response.sendResponse(res, response.build("EMAIL_EMPTY", { }));
        } else{
            const where = {
                type : "single",
                condition : {
                    email : email
                },
                select : ['id', 'email', 'status']
            }
            const userData = await accountServices.selectAdmins(where);
            if(userData && userData.status === "A"){
                // let code = Math.floor(100000 + Math.random() * 900000);
                let code = 654321;
                const updateOption = {
                    condition : {id : userData?.id},
                    data : {
                        users_otp : parseInt(code)
                    }
                }
                await accountServices.updateAdmin(updateOption);
                return response.sendResponse(res, response.build("SUCCESS", { result : {} }));
            } else if(userData && userData.status === "I"){
                return response.sendResponse(res, response.build("INACTIVE_ACCOUNT", {  }));
            } else if(userData && userData.status === "B"){
                return response.sendResponse(res, response.build("BLOCK_ACCOUNT", {  }));
            } else {
                return response.sendResponse(res, response.build("DELETE_ACCOUNT", {  }));
            }
            // if(userData && )
        }
    } catch (error) {
        console.log('error',error)
        return response.sendResponse(res, response.build('ERROR_SERVER_ERROR', { error }));
    }
}; //End of Function 

/*********************************************************************************
 * Function Name    :   verifyOTP
 * Purpose          :   This function is used for reset password
 * Created By       :   Afsar Ali
 * Created Data     :   28-06-2025
 * Updated By       :   
 * Update Data      :
 * Remarks          :
 ********************************************************************************/
exports.resetPassword = async function (req, res) {
    try {
        const {email, otp, password} = req.body;
        if(!email){
            return response.sendResponse(res, response.build("EMAIL_EMPTY", { }));
        } else if(!otp){
            return response.sendResponse(res, response.build("OTP_EMPTY", { }));
        } else if(!password){
            return response.sendResponse(res, response.build("PASSWORD_EMPTY", { }));
        } else{
            const where = {
                type : "single",
                condition : {
                    email : email
                },
                // select : { email : true, status : true }
                select : ['id', 'email', 'status', 'users_otp']
            }
            const userData = await accountServices.selectAdmins(where);
            if(userData && userData.status === "A"){
                if(parseInt(otp) === userData?.users_otp){
                    const hashedPassword = await createMD5Hash(password);
                    const updateOption = {
                        condition : {id : userData?.id},
                        data : {
                            password : hashedPassword,
                            users_otp : ""
                        }
                    }
                    const result = await accountServices.updateAdmin(updateOption);
                    return response.sendResponse(res, response.build("SUCCESS", { result : {} }));
                } else {
                    return response.sendResponse(res, response.build("INVALID_OTP", { }));
                }
            } else if(userData && userData.status === "I"){
                return response.sendResponse(res, response.build("INACTIVE_ACCOUNT", {  }));
            } else if(userData && userData.status === "B"){
                return response.sendResponse(res, response.build("BLOCK_ACCOUNT", {  }));
            } else {
                return response.sendResponse(res, response.build("DELETE_ACCOUNT", {  }));
            }
            // if(userData && )
        }
    } catch (error) {
        console.log('error',error)
        return response.sendResponse(res, response.build('ERROR_SERVER_ERROR', { error }));
    }
}; //End of Function

/*********************************************************************************
 * Function Name    :   verifyOTP
 * Purpose          :   This function is used for reset password
 * Created Data     :   28-06-2025
 ********************************************************************************/
exports.getSubAdmin = async function (req, res) {
    try {
        const userId = req.user.userId;
        const {type = "", condition, select, skip, limit } = req.body;
        if(!userId){
            return response.sendResponse(res, response.build("PERMISSION_ERROR", { }));
        } else{
            const where = {
                type : type,
                condition : {
                    ...condition,
                    admin_type : "Sub Admin",
                },
                select : select || '*',
                skip : skip || 0,
                limit : limit || 10
            }
            const result = await accountServices.selectAdmins(where);
            if(result && result?.length > 0){
                const option = {
                    type : "count",
                    condition : {
                        ...condition,
                        admin_type : "Sub Admin",
                    }
                }
                const count = await accountServices.selectAdmins(option);
                return response.sendResponse(res, response.build("SUCCESS", { result , ...{count : count || 0} }));
            } else{
                return response.sendResponse(res, response.build("SUCCESS", { result }));
            }
        }
    } catch (error) {
        console.log('error',error)
        return response.sendResponse(res, response.build('ERROR_SERVER_ERROR', { error }));
    }
}; //End of Function

/*********************************************************************************
 * Function Name    :   verifyOTP
 * Purpose          :   This function is used for reset password
 * Created Data     :   28-06-2025
 ********************************************************************************/
exports.addEditSubAdmin = async function (req, res) {
    try {
        const userId = req.user.userId;
        const {editId, name, email, phone, password } = req.body;
        if(!userId){
            return response.sendResponse(res, response.build("PERMISSION_ERROR", { }));
        } else if(!name){
            return response.sendResponse(res, response.build("NAME_EMPTY", { }));
        } else if(!email){
            return response.sendResponse(res, response.build("NAME_EMPTY", { }));
        } else if(!phone){
            return response.sendResponse(res, response.build("NAME_EMPTY", { }));
        } else if(!password && !editId){
            return response.sendResponse(res, response.build("NAME_EMPTY", { }));
        } else{
            const where = {
                type : "count",
                condition : {
                    email : email,
                    admin_type : "Sub Admin",
                }
            }
            const count = await accountServices.selectAdmins(where);
            if(count > 0 && !editId){
                return response.sendResponse(res, response.build("ERROR_ALREADY_EXIST", { }));
            } else {
                const ipAddress = await getIpAddress(req);
                const param = {
                    name : name,
                    phone : phone,
                }
                if(editId){
                    const updateParam = {
                        condition : {id : editId},
                        data : {
                            ...param,
                            updated_ip : ipAddress 
                        }
                    }
                    const result = await accountServices.updateAdmin(updateParam);
                    return response.sendResponse(res, response.build("SUCCESS", { result }));
                } else {
                    const hashedPassword = await createMD5Hash(password);
                    const insertParam = {
                        ...param,
                        email : email,
                        admin_type : "Sub Admin",
                        password : hashedPassword,
                        created_at : moment().format('YYYY-MM-DD HH:mm:ss')
                    }
                    const result = await accountServices.insertAdmin(insertParam);
                    return response.sendResponse(res, response.build("SUCCESS", { result }));
                }
            }
        }
    } catch (error) {
        console.log('error',error)
        return response.sendResponse(res, response.build('ERROR_SERVER_ERROR', { error }));
    }
}; //End of Function
/*********************************************************************************
 * Function Name    :   changeSubAdminStatus
 * Purpose          :   This function is used for reset password
 * Created Data     :   28-06-2025
 ********************************************************************************/
exports.changeSubAdminStatus = async function (req, res) {
    try {
        const userId = req.user.userId;
        const {admin_id, status } = req.body;
        if(!userId){
            return response.sendResponse(res, response.build("PERMISSION_ERROR", { }));
        } else{
            const ipAddress = await getIpAddress(req);
            const updateParam = {
                condition : { id : admin_id },
                data : { 
                    status : status,
                    updated_ip : ipAddress
                }
            }
            const result = await accountServices.updateAdmin(updateParam);
            return response.sendResponse(res, response.build("SUCCESS", { result }));
        } 
    } catch (error) {
        
    }
}
