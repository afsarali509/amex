const router = require('express').Router({
    caseSensitive   : true,
    strict          : true
});

const requestController = require('./requestController');
const authCheck = require('../../../../util/authCheck')

router.post('/list', authCheck, requestController.list);
router.post('/addeditdata', authCheck, requestController.addEditData);
router.post('/change-status', authCheck, requestController.changeStatus);

exports.router = router;    