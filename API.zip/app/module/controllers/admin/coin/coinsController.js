const response = require('../../../../util/response');
const commonServices = require("../../../services/commonServices");
const { getIpAddress } = require("../../../../util/utility"); 
const { createMD5Hash } = require("../../../../util/crypto");
const moment = require('moment');
/*********************************************************************************
 * Function Name    :   list
 * Purpose          :   This function is used for reset password
 * Created Data     :   28-06-2025
 ********************************************************************************/
exports.list = async function (req, res) {
    try {
        const userId = req.user.userId;
        const {type = "", condition, select, skip, limit } = req.body;
        if(!userId){
            return response.sendResponse(res, response.build("PERMISSION_ERROR", { }));
        } else{
            const where = {
                type : type,
                condition : {
                    ...condition,
                },
                select : select || '*',
                skip : skip || 0,
                limit : limit || 10
            }
            const result = await commonServices.select(where, 'coins');
            if(result && result?.length > 0){
                const option = {
                    type : "count",
                    condition : {
                        ...condition,
                    }
                }
                const count = await commonServices.select(option, 'coins');
                return response.sendResponse(res, response.build("SUCCESS", { result , ...{count : count || 0} }));
            } else{
                return response.sendResponse(res, response.build("SUCCESS", { result }));
            }
        }
    } catch (error) {
        console.log('error',error)
        return response.sendResponse(res, response.build('ERROR_SERVER_ERROR', { error }));
    }
}; //End of Function

/*********************************************************************************
 * Function Name    :   verifyOTP
 * Purpose          :   This function is used for reset password
 * Created Data     :   28-06-2025
 ********************************************************************************/
exports.addEditData = async function (req, res) {
    try {
        const {editId, coin, symbol, coin_id} = req.body;
        if(!coin){
            return response.sendResponse(res, response.build("COIN_NAME_EMPTY", { }));
        }else if(!symbol){
            return response.sendResponse(res, response.build("COIN_SYMBOL_EMPTY", { }));
        }else if(!coin_id){
            return response.sendResponse(res, response.build("COIN_ID_EMPTY", { }));
        } else{
            const ipAddress = await getIpAddress(req);
            const where = {
                type : "count",
                condition : {
                    coin_id : coin_id
                },
            }
            const userCount = await commonServices.select(where, 'coins');
            if(!editId && userCount === 0){
                    const param = {
                        coin : coin,
                        symbol : symbol,
                        coin_id : coin_id,
                        status : "A",
                        created_at : moment().format('YYYY-MM-DD HH:mm:ss'),
                        created_ip : ipAddress
                    }
                    const result = await commonServices.insert(param, 'coins');
                    return response.sendResponse(res, response.build("SUCCESS", { result }));
            } else if(editId) {
                const updateOption = {
                    condition : { id : parseInt(editId) },
                    data : {
                        coin : coin,
                        symbol : symbol,
                        coin_id : coin_id,
                        updated_at : moment().format('YYYY-MM-DD HH:mm:ss'),
                        updated_ip : ipAddress
                    }
                }
                const result = await commonServices.update(updateOption,'coins');
                return response.sendResponse(res, response.build("SUCCESS", { result : result }));
            } else {
                return response.sendResponse(res, response.build("ERROR_ALREADY_EXIST", { }));
            }
        }
    } catch (error) {
        console.log('error',error)
        return response.sendResponse(res, response.build('ERROR_SERVER_ERROR', { error }));
    }
}; //End of Function  //End of Function
/*********************************************************************************
 * Function Name    :   changeStatus
 * Purpose          :   This function is used for reset password
 * Created Data     :   28-06-2025
 ********************************************************************************/
exports.changeStatus = async function (req, res) {
    try {
        const userId = req.user.userId;
        const {coin_id, status } = req.body;
        if(!userId){
            return response.sendResponse(res, response.build("PERMISSION_ERROR", { }));
        } else{
            const ipAddress = await getIpAddress(req);
            const updateParam = {
                condition : { id : coin_id },
                data : { 
                    status : status,
                    updated_ip : ipAddress
                }
            }
            const result = await commonServices.update(updateParam, 'coins');
            return response.sendResponse(res, response.build("SUCCESS", { result }));
        } 
    } catch (error) {
        
    }
}
