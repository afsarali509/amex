const router = require('express').Router({
    caseSensitive   : true,
    strict          : true
});

const coinsController = require('./coinsController');
const authCheck = require('../../../../util/authCheck')

router.post('/list', authCheck, coinsController.list);
router.post('/addeditdata', authCheck, coinsController.addEditData);
router.post('/change-status', authCheck, coinsController.changeStatus);

exports.router = router;    