const response = require('../../../../util/response');
const commonServices = require("../../../services/commonServices");
const { getIpAddress } = require("../../../../util/utility"); 
const { createMD5Hash } = require("../../../../util/crypto");
const moment = require('moment');
/*********************************************************************************
 * Function Name    :   list
 * Purpose          :   This function is used for reset password
 * Created Data     :   28-06-2025
 ********************************************************************************/
exports.list = async function (req, res) {
    try {
        const userId = req.user.userId;
        const {type = "", condition, select, skip, limit } = req.body;
        if(!userId){
            return response.sendResponse(res, response.build("PERMISSION_ERROR", { }));
        } else{
            const where = {
                type : type,
                condition : {
                    ...condition,
                },
                select : select || '*',
                skip : skip || 0,
                limit : limit || 10
            }
            const result = await commonServices.select(where, 'users');
            if(result && result?.length > 0){
                const option = {
                    type : "count",
                    condition : {
                        ...condition,
                    }
                }
                const count = await commonServices.select(option, 'users');
                return response.sendResponse(res, response.build("SUCCESS", { result , ...{count : count || 0} }));
            } else{
                return response.sendResponse(res, response.build("SUCCESS", { result }));
            }
        }
    } catch (error) {
        console.log('error',error)
        return response.sendResponse(res, response.build('ERROR_SERVER_ERROR', { error }));
    }
}; //End of Function

/*********************************************************************************
 * Function Name    :   verifyOTP
 * Purpose          :   This function is used for reset password
 * Created Data     :   28-06-2025
 ********************************************************************************/
exports.addEditData = async function (req, res) {
    try {
        const {editId, name, email, phone, password} = req.body;
        if(!name){
            return response.sendResponse(res, response.build("NAME_EMPTY", { }));
        }else if(!email){
            return response.sendResponse(res, response.build("EMAIL_EMPTY", { }));
        }else if(!phone){
            return response.sendResponse(res, response.build("PHONE_EMPTY", { }));
        } else if(!password && !editId){
            return response.sendResponse(res, response.build("PASSWORD_EMPTY", { }));
        } else{
            const where = {
                type : "count",
                condition : {
                    $or : [
                        {email : email},
                        {phone : phone}
                    ]
                }
            }
            const userCount = await commonServices.select(where, 'users');
            const ipAddress = await getIpAddress(req);
            if(userCount === 0 && !editId){
                const hashedPassword = await createMD5Hash(password);
                const param = {
                    name : name,
                    email : email,
                    phone : phone,
                    password : hashedPassword,
                    status : "A",
                    created_at : moment().format('YYYY-MM-DD HH:mm:ss'),
                    created_ip : ipAddress
                }

                const result = await commonServices.insert(param, 'users');
                return response.sendResponse(res, response.build("SUCCESS", { result }));
            } else if(userCount > 0 && editId){
                hashedPassword2 = "";
                if(password){
                    hashedPassword2 = await createMD5Hash(password);
                }
                const updateParam = {
                    condition : { id  : editId},
                    data : {
                        name : name,
                        ...(password && {password : hashedPassword2})
                    }
                }
                const result = await commonServices.update(updateParam, 'users');
                return response.sendResponse(res, response.build("SUCCESS", { result }));
            } else{
                return response.sendResponse(res, response.build("ALREADY_REGISTERED", {  }));
            }
        }
    } catch (error) {
        console.log('error',error)
        return response.sendResponse(res, response.build('ERROR_SERVER_ERROR', { error }));
    }
}; //End of Function  //End of Function
/*********************************************************************************
 * Function Name    :   changeStatus
 * Purpose          :   This function is used for reset password
 * Created Data     :   28-06-2025
 ********************************************************************************/
exports.changeStatus = async function (req, res) {
    try {
        const userId = req.user.userId;
        const {user_id, status } = req.body;
        if(!userId){
            return response.sendResponse(res, response.build("PERMISSION_ERROR", { }));
        } else{
            const ipAddress = await getIpAddress(req);
            const updateParam = {
                condition : { id : user_id },
                data : { 
                    status : status,
                    updated_ip : ipAddress
                }
            }
            const result = await commonServices.update(updateParam, 'users');
            return response.sendResponse(res, response.build("SUCCESS", { result }));
        } 
    } catch (error) {
        
    }
}
