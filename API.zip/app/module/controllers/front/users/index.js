const router = require('express').Router({
    caseSensitive   : true,
    strict          : true
});

const accountsController = require('./usersControllers.js');

router.post('/registration', accountsController.registration);
router.post('/login', accountsController.login);
router.post('/sent-otp', accountsController.sentOTP);
router.post('/verify-otp', accountsController.verifyOtp);
router.post('/forgot-password', accountsController.forgotPassword);
router.post('/reset-password', accountsController.resetPassword);

exports.router = router;    