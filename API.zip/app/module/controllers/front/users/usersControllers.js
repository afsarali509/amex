const response = require('../../../../util/response');
const commonServices = require("../../../services/commonServices");
const { createMD5Hash, checkMD5Password} = require("../../../../util/crypto");
const moment = require('moment');
const {getIpAddress} = require("../../../../util/utility");
const { generateToken } = require("../../../../util/authToken");
/*********************************************************************************
 * Function Name    :   registration
 * Purpose          :   This function is used for registration
 * Created By       :   Afsar Ali
 * Created Date     :   27-06-2025
 ********************************************************************************/
exports.registration = async function (req, res) {
    try {
        const {name, email, phone, password} = req.body;
        if(!name){
            return response.sendResponse(res, response.build("NAME_EMPTY", { }));
        }else if(!email){
            return response.sendResponse(res, response.build("EMAIL_EMPTY", { }));
        }else if(!phone){
            return response.sendResponse(res, response.build("PHONE_EMPTY", { }));
        } else if(!password){
            return response.sendResponse(res, response.build("PASSWORD_EMPTY", { }));
        } else{
            const where = {
                type : "count",
                condition : {
                    $or : [
                        {email : email},
                        {phone : phone}
                    ]
                }
            }
            const userCount = await commonServices.select(where, 'users');
            if(userCount === 0){
                const hashedPassword = await createMD5Hash(password);
                const ipAddress = await getIpAddress(req);
                const param = {
                    name : name,
                    email : email,
                    phone : phone,
                    password : hashedPassword,
                    status : "A",
                    created_at : moment().format('YYYY-MM-DD HH:mm:ss'),
                    created_ip : ipAddress
                }

                const result = await commonServices.insert(param, 'users');
                return response.sendResponse(res, response.build("SUCCESS", { result }));
            } else{
                return response.sendResponse(res, response.build("ALREADY_REGISTERED", {  }));
            }
        }
    } catch (error) {
        console.log('error',error)
        return response.sendResponse(res, response.build('ERROR_SERVER_ERROR', { error }));
    }
}; //End of Function 

/*********************************************************************************
 * Function Name    :   login
 * Purpose          :   This function is used for get login
 * Created By       :   Afsar Ali
 * Created Date     :   09-12-2024
 ********************************************************************************/
exports.login = async function (req, res) {
    try {
        const {email, phone, password} = req.body;
        if(!email && !phone){
            return response.sendResponse(res, response.build("EMAIL_EMPTY", { }));
        } else if(!password){
            return response.sendResponse(res, response.build("PASSWORD_EMPTY", { }));
        } else{
            const where = {
                type : "single",
                condition : {
                    ...(email ? {email : email} : {phone : phone})
                },
                select : ['id', 'email', 'phone', 'status', 'password']
            }
            const userData = await commonServices.select(where, 'users');
            if(userData && userData.status === "A"){
                const hashedPassword = await createMD5Hash(password);
                if(hashedPassword === userData?.password){
                    const ipAddress = await getIpAddress(req);
                    const token = await generateToken(userData?.id, 
                        "Users", 
                        "Users", 
                        '365 days');
                    const updateOption = {
                        condition : {id : userData?.id},
                        data : {
                            token : token,
                            login_at : moment().format('YYYY-MM-DD HH:mm:ss'),
                            login_ip : ":1",
                            updated_ip : ipAddress
                        }
                    }
                    const result = await commonServices.update(updateOption,'users');
                   
                    return response.sendResponse(res, response.build("SUCCESS", { result : result[0] }));
                } else {
                    return response.sendResponse(res, response.build("INVALID_LOGIN_CREDENTIAL", { }));
                }
            } else if(userData && userData.status === "I"){
                return response.sendResponse(res, response.build("INACTIVE_ACCOUNT", {  }));
            } else if(userData && userData.status === "B"){
                return response.sendResponse(res, response.build("BLOCK_ACCOUNT", {  }));
            } else {
                return response.sendResponse(res, response.build("DELETE_ACCOUNT", {  }));
            }
            // if(userData && )
        }
    } catch (error) {
        console.log('error',error)
        return response.sendResponse(res, response.build('ERROR_SERVER_ERROR', { error }));
    }
}; //End of Function 

/*********************************************************************************
 * Function Name    :   registration
 * Purpose          :   This function is used for registration
 * Created By       :   Afsar Ali
 * Created Date     :   27-06-2025
 ********************************************************************************/
exports.sentOTP = async function (req, res) {
    try {
        const {email, phone} = req.body;
        if(!email && !phone){
            return response.sendResponse(res, response.build("EMAIL_EMPTY", { }));
        }  else{
            const where = {
                ...(email && {email : email}),
                ...(phone && {phone : phone})
            }
            await commonServices.delete(where, 'verifyotp');
            // let code = Math.floor(100000 + Math.random() * 900000);
            let code = 654321;
            const param = {
                ...(email && {email : email}),
                ...(phone && {phone : phone}),
                otp : code,
            }
            await commonServices.insert(param, 'verifyotp');
            return response.sendResponse(res, response.build("SUCCESS", { }));
        }
    } catch (error) {
        console.log('error',error)
        return response.sendResponse(res, response.build('ERROR_SERVER_ERROR', { error }));
    }
}

/*********************************************************************************
 * Function Name    :   verifyOtp
 * Purpose          :   This function is used for registration
 * Created By       :   Afsar Ali
 * Created Date     :   27-06-2025
 ********************************************************************************/
exports.verifyOtp = async function (req, res) {
    try {
        const {email, phone, otp} = req.body;
        if(!email && !phone){
            return response.sendResponse(res, response.build("EMAIL_EMPTY", { }));
        } else if(!otp){
            return response.sendResponse(res, response.build("OTP_EMPTY", { }));
        } else{
            const options = {
                type : "single",
                condition : {
                    ...(email && {email : email}),
                    ...(phone && {phone : phone}),
                }
            }
            const data = await commonServices.select(options, 'verifyotp');
            if(data && data?.otp === parseInt(otp)){
                const where = {
                    ...(email && {email : email}),
                    ...(phone && {phone : phone})
                }
                await commonServices.delete(where, 'verifyotp');
                return response.sendResponse(res, response.build("SUCCESS", { }));
            } else {
                return response.sendResponse(res, response.build("INVALID_OTP", { }));
            }
        }
    } catch (error) {
        console.log('error',error)
        return response.sendResponse(res, response.build('ERROR_SERVER_ERROR', { error }));
    }
}

/*********************************************************************************
 * Function Name    :   resetPassword
 * Purpose          :   This function is used for reset password
 * Created By       :   Afsar Ali
 * Created Date     :   27-06-2025
 ********************************************************************************/
exports.forgotPassword = async function (req, res) {
    try {
        const {email, phone} = req.body;
        if(!email && !phone){
            return response.sendResponse(res, response.build("EMAIL_EMPTY", { }));
        } else{
            const options = {
                type : "single",
                condition : {
                    ...(email && {email : email}),
                    ...(phone && {phone : phone}),
                }
            }
            const userData = await commonServices.select(options, 'users');
            if(userData && userData?.status === 'A'){
                const where = {
                ...(email && {email : email}),
                ...(phone && {phone : phone})
                }
                await commonServices.delete(where, 'verifyotp');
                // let code = Math.floor(100000 + Math.random() * 900000);
                let code = 654321;
                const param = {
                    ...(email && {email : email}),
                    ...(phone && {phone : phone}),
                    otp : code,
                }
                await commonServices.insert(param, 'verifyotp');
                return response.sendResponse(res, response.build("SUCCESS", { }));
            } else {
                return response.sendResponse(res, response.build("INVALID_OTP", { }));
            }
        }
    } catch (error) {
        console.log('error',error)
        return response.sendResponse(res, response.build('ERROR_SERVER_ERROR', { error }));
    }
}

/*********************************************************************************
 * Function Name    :   resetPassword
 * Purpose          :   This function is used for reset password
 * Created By       :   Afsar Ali
 * Created Date     :   27-06-2025
 ********************************************************************************/
exports.resetPassword = async function (req, res) {
    try {
        const {email, phone, otp, password} = req.body;
        if(!email && !phone){
            return response.sendResponse(res, response.build("EMAIL_EMPTY", { }));
        } else if(!otp){
            return response.sendResponse(res, response.build("OTP_EMPTY", { }));
        } else if (!password){
            return response.sendResponse(res, response.build("PASSWORD_EMPTY", { }));
        } else{
            const options = {
                type : "single",
                condition : {
                    ...(email && {email : email}),
                    ...(phone && {phone : phone}),
                }
            }
            const data = await commonServices.select(options, 'verifyotp');
            if(data && data?.otp === parseInt(otp)){
                const where = {
                    ...(email && {email : email}),
                    ...(phone && {phone : phone})
                }
                await commonServices.delete(where, 'verifyotp');

                const userOption = {
                    type : "single",
                    condition : {
                        ...(email && {email : email}),
                        ...(phone && {phone : phone})
                    },
                    select : ['id', 'status']
                }
                const userData = await commonServices.select(userOption, 'users');
                if(userData){
                    const ipAddress = await getIpAddress(req);
                    const hashedPassword = await createMD5Hash(password);
                    const updateOption = {
                        condition : {id : userData?.id},
                        data : {
                            password : hashedPassword,
                            token : "",
                            updated_ip : ipAddress 
                        }
                    }
                    await commonServices.update(updateOption, 'users');
                    return response.sendResponse(res, response.build("SUCCESS", { }));
                } else{
                    return response.sendResponse(res, response.build("ERROR_DATA_NOT_FOUND", { }));
                }
            } else {
                return response.sendResponse(res, response.build("INVALID_OTP", { }));
            }
        }
    } catch (error) {
        console.log('error',error)
        return response.sendResponse(res, response.build('ERROR_SERVER_ERROR', { error }));
    }
}

