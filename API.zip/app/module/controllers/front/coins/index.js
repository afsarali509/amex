const router = require('express').Router({
    caseSensitive   : true,
    strict          : true
});

const coinController = require('./coinControllers.js');

// router.post('/list', accountsController.list);
router.post('/list', coinController.list);
router.post('/buy', coinController.buyCoin);
router.post('/sell', coinController.sellCoin);

exports.router = router;    