const response = require('../../../../util/response');
const { getIpAddress } = require('../../../../util/utility');
const commonServices = require("../../../services/commonServices");
/*********************************************************************************
 * Function Name    :   list
 * Purpose          :   This function is used for registration
 * Created Date     :   27-06-2025
 ********************************************************************************/
exports.list = async function (req, res) {
    try {
        const where = {
            condition : { status : "A" },
            skip : 0,
            limit : 100
        }
        const result = await commonServices.select(where,'coins');
        return response.sendResponse(res, response.build("SUCCESS", { result : result }));
    } catch (error) {
        console.log('error',error)
        return response.sendResponse(res, response.build('ERROR_SERVER_ERROR', { error }));
    }
}; //End of Function 

/*********************************************************************************
 * Function Name    :   buyCoin
 * Purpose          :   This function is used for registration
 * Created Date     :   27-06-2025
 ********************************************************************************/
exports.buyCoin = async function (req, res) {
    try {
        const { coin_id, amount, email, phone } = req.body;
        if(!coin_id){
            return response.sendResponse(res, response.build('COIN_EMPTY', { error }));
        } else if(!amount || amount === '0'){
            return response.sendResponse(res, response.build('AMOUNT_EMPTY', { error }));
        } else if(!email){
            return response.sendResponse(res, response.build('EMAIL_EMPTY', { error }));
        } else if(!phone){
            return response.sendResponse(res, response.build('PHONE_EMPTY', { error }));
        } else {
            const where = {
                type : "single",
                condition : { coin_id : coin_id, status : "A" },
            }
            const coinData = await commonServices.select(where,'coins');
            if(coinData){
                const ipAddress = await getIpAddress(req) 
                const params = {
                    coin_id         : coin_id,
                    current_price   : coinData?.current_price,
                    amount          : amount,
                    email           : email,
                    phone           : phone,
                    type            : 'Purchase',
                    status          : 'Pending',
                    created_at      : new Date(),
                    created_ip      : ipAddress 
                }
                const result = await commonServices.insert(params, 'request');
                return response.sendResponse(res, response.build("SUCCESS", { result : result }));
            } else{
                return response.sendResponse(res, response.build("ERROR_DATA_NOT_FOUND", { }));
            }
        }
        
    } catch (error) {
        console.log('error',error)
        return response.sendResponse(res, response.build('ERROR_SERVER_ERROR', { error }));
    }
}; //End of Function 

/*********************************************************************************
 * Function Name    :   sellCoin
 * Purpose          :   This function is used for registration
 * Created Date     :   27-06-2025
 ********************************************************************************/
exports.sellCoin = async function (req, res) {
    try {
        const { coin_id, amount, email, phone } = req.body;
        if(!coin_id){
            return response.sendResponse(res, response.build('COIN_EMPTY', { error }));
        } else if(!amount || amount === '0'){
            return response.sendResponse(res, response.build('AMOUNT_EMPTY', { error }));
        } else if(!email){
            return response.sendResponse(res, response.build('EMAIL_EMPTY', { error }));
        } else if(!phone){
            return response.sendResponse(res, response.build('PHONE_EMPTY', { error }));
        } else {
            const where = {
                type : "single",
                condition : { coin_id : coin_id, status : "A" },
            }
            const coinData = await commonServices.select(where,'coins');
            if(coinData){
                const ipAddress = await getIpAddress(req) 
                const params = {
                    coin_id         : coin_id,
                    current_price   : coinData?.current_price,
                    amount          : amount,
                    email           : email,
                    phone           : phone,
                    type            : 'Sell',
                    status          : 'Pending',
                    created_at      : new Date(),
                    created_ip      : ipAddress 
                }
                const result = await commonServices.insert(params, 'request');
                return response.sendResponse(res, response.build("SUCCESS", { result : result }));
            } else{
                return response.sendResponse(res, response.build("ERROR_DATA_NOT_FOUND", { }));
            }
        }
        
    } catch (error) {
        console.log('error',error)
        return response.sendResponse(res, response.build('ERROR_SERVER_ERROR', { error }));
    }
}; //End of Function 
