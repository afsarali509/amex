const basePath = __basePath;

module.exports = {
    APPKEY : "d42a0d190464a2be90977c3996382811",//APP API BY ALGOSOFT DEVELOPED BY AFSAR ALI
    EMAIL_API_KEY : "<API-KEY>",
    SENDER_EMAIL : "<SENDER-EMAIL>",
   
    NOTIFICATIONKEY : "",
    path: {
        base                        : basePath,
        app                         : basePath + 'app/',
        module                      : basePath + 'app/module/controller/',
        log                         : basePath + 'asset/log/',
        moduleV1                    : basePath + 'app/module/controller/v1/',
        faviconImg                  : '/favicon.ico'
    },
    crons: {
        cronExpForGetAllOffers: '0 */1 * * *',
        cronTimezone: 'Asia/Kolkata'
    },
    roles:{
        SUPERADMIN:"SUPERADMIN",
        USER:"USER",
    },
    superadminAuthIssuerName: "SUPERADMIN",
    authTokenSuperAdminAuthExpiresIn:"365 days",
    
    subadminAuthIssuerName: "SUBADMIN",
    authTokenSubAdminAuthExpiresIn:"365 days",

    userAuthIssuerName: "USER",
    authTokenUserAuthExpiresIn:"365 days",

    OtpExpiry:{
            value:1,
            duration:"minutes"
        },
    OtpRetry:{
            value:1,
            duration:"minutes"
    },
    pageLimit: 10,
    pageSkip:0,
    adminForgotPasswordPostFix: "FORGOTPASSWORD",
    userForgotPasswordPostFix: "FORGOTPASSWORD",
    USERTYPE : {
        USER        : "User",
        SUPERADMIN  : "Super Admin",
        SUBADMIN    : "Sub Admin"
    },
    RECHARGE_API  : 'EJFgkl8WV8j6QdeHiJTS9S',
    RECHARGE_BASE_URL  : 'https://api.dingconnect.com/api/V1'
};

