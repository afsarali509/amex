const express = require("express");
const cookieParser = require("cookie-parser");
const publicDir = require("path").join("../app/", "/public");

module.exports = (app) => {
  app.use(cookieParser());
  app.use(express.static(publicDir));
  //Admin Routes
  app.use("/v1/admin/accounts", require("../module/controllers/admin/accounts").router);
  app.use("/v1/admin/users", require("../module/controllers/admin/users").router);
  app.use("/v1/admin/coins", require("../module/controllers/admin/coin").router);
  
  //Frond Routes
  app.use("/v1/front/users", require("../module/controllers/front/users").router);
  app.use("/v1/front/coins", require("../module/controllers/front/coins").router);

};
