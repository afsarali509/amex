const moment = require('moment');

function createSlug(input) {
  return input
    .toString()                    // Convert to string
    .toLowerCase()                 // Convert to lowercase
    .replace(/\s+/g, '-')          // Replace spaces with hyphens
    .replace(/[^\w-]+/g, '')       // Remove non-word characters (excluding hyphens)
    .replace(/--+/g, '-');         // Replace multiple hyphens with a single hyphen
}
//This function is used for validate promocode date
function isPromoCodeValid(promoCode) {
  const currentDateTime = moment();
  const validDateTime = moment(promoCode.valid_date);
  const expireDateTime = moment(promoCode.expire_date);

  validDateTime.set({
    hour: parseInt(promoCode.valid_time.split(':')[0]),
    minute: parseInt(promoCode.valid_time.split(':')[1])
  });

  expireDateTime.set({
    hour: parseInt(promoCode.expire_time.split(':')[0]),
    minute: parseInt(promoCode.expire_time.split(':')[1])
  });
  
  if (currentDateTime.isBetween(validDateTime, expireDateTime, null, '[]')) {
    return true;
  } else {
    return false;
  }
}

function getIpAddress(req){
  try {
    return req.headers['x-forwarded-for'] || req.socket.remoteAddress;
  } catch (error) {
    return ':1'
  }
}

function generateRandomString(length) {
  const characters = '123456789ABCDEFGHJKMNPQRSTUVWXYZ';
  let result = '';
  const charactersLength = characters.length;
  
  for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  
  return result;
}

function calculateTotalDays(isoDate) {
  const inputDate = new Date(isoDate);
  const today = new Date();

  // Reset time to ignore partial day differences
  inputDate.setHours(0, 0, 0, 0);
  today.setHours(0, 0, 0, 0);

  const diffTime = today - inputDate;
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

  return diffDays;
}


module.exports = {
    createSlug,
    isPromoCodeValid,
    getIpAddress,
    generateRandomString,
    calculateTotalDays
};