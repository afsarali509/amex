const { postRequest } = require("./API");
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
/*********************************************************
* Function Name : login
* Description   : user login
* Date          : 29-06-2025 
*********************************************************/
export const userRegistration = async (options) =>{
    try {
        const params = {
            url : `${API_BASE_URL}/front/users/registration`,
            postData : options
        }
        const res = await postRequest(params);
        if(res.status === true || res.status === 200){
            return {status : true, result : res?.data?.response?.result, count : res?.data?.response?.count};
        } else{
            return {status : false, message:res?.response?.data?.statusMessage}
        }
    } catch (error) {
        console.log(error)
        return {status : false, message:"Under Maintenance, Please try after some time."}
    }
};//End of Function

/*********************************************************
* Function Name : sent-otp
* Description   : sent-otp
* Date          : 29-06-2025 
*********************************************************/
export const sendOTP = async (options) =>{
    try {
        const params = {
            url : `${API_BASE_URL}/front/users/sent-otp`,
            postData : options
        }
        const res = await postRequest(params);
        if(res.status === true || res.status === 200){
            return {status : true, result : res?.data?.response?.result};
        } else{
            return {status : false, message:res?.response?.data?.statusMessage}
        }
    } catch (error) {
        console.log(error)
        return {status : false, message:"Under Maintenance, Please try after some time."}
    }
};//End of Function

/*********************************************************
* Function Name : login
* Description   : user login
* Date          : 29-06-2025 
*********************************************************/
export const login = async (options) =>{
    try {
        const params = {
            url : `${API_BASE_URL}/front/users/login`,
            postData : options
        }
        const res = await postRequest(params);
        if(res.status === true || res.status === 200){
            sessionStorage.setItem('USER-TOKEN', res.data.response.result.token);
            sessionStorage.setItem('USER-INFO', JSON.stringify(res.data.response.result));
            return {status : true, result : res?.data?.response?.result};
        } else{
            return {status : false, message:res?.response?.data?.statusMessage}
        }
    } catch (error) {
        console.log(error)
        return {status : false, message:"Under Maintenance, Please try after some time."}
    }
};//End of Function

/*********************************************************
* Function Name : verifyOTP
* Description   : user login
* Date          : 29-06-2025 
*********************************************************/
export const verifyOTP = async (options) =>{
    try {
        const params = {
            url : `${API_BASE_URL}/front/users/sent-otp`,
            postData : options
        }
        const res = await postRequest(params);
        if(res.status === true || res.status === 200){
            return {status : true, result : res?.data?.response?.result, count : res?.data?.response?.count};
        } else{
            return {status : false, message:res?.response?.data?.statusMessage}
        }
    } catch (error) {
        console.log(error)
        return {status : false, message:"Under Maintenance, Please try after some time."}
    }
};//End of Function

/*********************************************************
* Function Name : forgotPassword
* Description   : forgot password
* Date          : 30-06-2025 
*********************************************************/
export const forgotPassword = async (options) =>{
    try {
        const params = {
            url : `${API_BASE_URL}/front/users/forgot-password`,
            postData : options
        }
        const res = await postRequest(params);
        if(res.status === true || res.status === 200){
            return {status : true, result : res?.data?.response?.result};
        } else{
            return {status : false, message:res?.response?.data?.statusMessage}
        }
    } catch (error) {
        console.log(error)
        return {status : false, message:"Under Maintenance, Please try after some time."}
    }
};//End of Function

/*********************************************************
* Function Name : resetPassword
* Description   : reset login password
* Date          : 30-06-2025 
*********************************************************/
export const resetPassword = async (options) =>{
    try {
        const params = {
            url : `${API_BASE_URL}/front/users/reset-password`,
            postData : options
        }
        const res = await postRequest(params);
        if(res.status === true || res.status === 200){
            return {status : true, result : res?.data?.response?.result};
        } else{
            return {status : false, message:res?.response?.data?.statusMessage}
        }
    } catch (error) {
        console.log(error)
        return {status : false, message:"Under Maintenance, Please try after some time."}
    }
};//End of Function