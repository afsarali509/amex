const { postRequest } = require("./API");
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
/*********************************************************
* Function Name : resetPassword
* Description   : reset login password
* Date          : 30-06-2025 
*********************************************************/
export const list = async (options) =>{
    try {
        const params = {
            url : `${API_BASE_URL}/front/coins/list`,
            postData : options
        }
        const res = await postRequest(params);
        if(res.status === true || res.status === 200){
            return {status : true, result : res?.data?.response?.result};
        } else{
            return {status : false, message:res?.response?.data?.statusMessage}
        }
    } catch (error) {
        console.log(error)
        return {status : false, message:"Under Maintenance, Please try after some time."}
    }
};//End of Function

/*********************************************************
* Function Name : buyRequest
* Description   : reset login password
* Date          : 30-06-2025 
*********************************************************/
export const buyRequest = async (options) =>{
    try {
        const params = {
            url : `${API_BASE_URL}/front/coins/buy`,
            postData : options
        }
        const res = await postRequest(params);
        if(res.status === true || res.status === 200){
            return {status : true, result : res?.data?.response?.result};
        } else{
            return {status : false, message:res?.response?.data?.statusMessage}
        }
    } catch (error) {
        console.log(error)
        return {status : false, message:"Under Maintenance, Please try after some time."}
    }
};//End of Function

/*********************************************************
* Function Name : saleRequest
* Description   : reset login password
* Date          : 30-06-2025 
*********************************************************/
export const sellRequest = async (options) =>{
    try {
        const params = {
            url : `${API_BASE_URL}/front/coins/sell`,
            postData : options
        }
        const res = await postRequest(params);
        if(res.status === true || res.status === 200){
            return {status : true, result : res?.data?.response?.result};
        } else{
            return {status : false, message:res?.response?.data?.statusMessage}
        }
    } catch (error) {
        console.log(error)
        return {status : false, message:"Under Maintenance, Please try after some time."}
    }
};//End of Function