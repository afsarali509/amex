import axios from "axios";
import { API_KEY, GOOGLE_MAP_API } from "../config/constants";

/*****************************************************
 * This function is use to generate GET Request
 *****************************************************/
export const getRequest = async (options)=>{
    try {
        const { url } = options;
        const token = sessionStorage.getItem('ADMIN-TOKEN');
        const headers = { authToken : token, key : API_KEY };
        const response = await axios.get(url, { headers });
        const data = response.data.response.result;
        return data;
    } catch (error) {
        return false;
    }
} //End of the function

/*****************************************************
 * This function is use to generate POST Request
 *****************************************************/
export const postRequest = async (options, cancelToken={})=>{
    try{
        const { url, postData ={} } = options;
        const token = sessionStorage.getItem('ADMIN-TOKEN');
        const headers = { authToken : token, key : API_KEY };
        return await axios.post(url, postData, { headers }, { cancelToken: cancelToken.token });
    } catch(error){
        if(error?.response.status === 500 && error?.response.data.response.error === "Invalid or Expired Token"){
            sessionStorage.removeItem('ADMIN-INFO');
            sessionStorage.removeItem('ADMIN-TOKEN');
        }
        return error;
    }
} //End of the function
