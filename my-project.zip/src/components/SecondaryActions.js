import React from 'react';
import './SecondaryActions.css';

const actions = [
  { icon: <img src="/images/deposit.png" alt="Deposit" className="secondary-action-img" />, label: 'Deposit' },
  { icon: <img src="/images/convert.png" alt="Convert" className="secondary-action-img" />, label: 'Convert' },
  { icon: <img src="/images/loan.png" alt="Loan" className="secondary-action-img" />, label: 'Loan' },
  { icon: <img src="/images/support.png" alt="Support" className="secondary-action-img" />, label: 'Support' },
  { icon: <img src="/images/invite.png" alt="Invite" className="secondary-action-img" />, label: 'Invite' },
];

const SecondaryActions = () => {
  return (
    <div className="secondary-actions">
      {actions.map((action, index) => (
        <div key={index} className="secondary-action">
          {action.icon}
          <span>{action.label}</span>
        </div>
      ))}
    </div>
  );
};

export default SecondaryActions; 