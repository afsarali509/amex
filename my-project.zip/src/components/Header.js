import React from 'react';
import './Header.css';

const Header = () => {
  return (
    <div className="header">
      <span role="img" aria-label="india-flag" style={{fontSize: '24px'}}>
        <img src="/images/india.png" alt="india-flag" style={{width: '24px', height: '24px'}} />
      </span>
    </div>
  );
};

export default Header; 