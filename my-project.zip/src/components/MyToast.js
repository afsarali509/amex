import { Toast, ToastContainer } from 'react-bootstrap';

const typeColors = {
  success: '#1ecb81',
  error: '#ff4d4f',
  info: '#1677ff',
};

const MyToast = ({show, setShow, msg, type = 'info'}) => {
//   const [show, setShow] = useState(false);

  const borderColor = typeColors[type] || typeColors.info;

  return (
    <>
      <ToastContainer position="bottom-end" className="p-3">
        <Toast
          onClose={() => setShow(false)}
          show={show}
          delay={3000}
          autohide
          bg={'dark'}
          style={{
            borderLeft: `6px solid ${borderColor}`,
            boxShadow: '0 2px 12px rgba(0,0,0,0.4)',
            minWidth: 280
          }}
        >
          {/* <Toast.Header>
            <strong className="me-auto">Notification</strong>
          </Toast.Header> */}
          <Toast.Body className="text-white" style={{fontWeight: 500, fontSize: 16}}>{msg}</Toast.Body>
        </Toast>
      </ToastContainer>
    </>
  );
};

export default MyToast;
