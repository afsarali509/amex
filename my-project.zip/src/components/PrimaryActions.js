import React from 'react';
import './PrimaryActions.css';

const PrimaryActions = () => {
  return (
    <div className="primary-actions">
      <div className="action-card">
        <div className="action-card-main">
          <img src="/images/usdt.png" alt="USDT Staking" className="primary-action-img" />
          <span>USDT Staking</span>
        </div>
        <img src="/images/trade1.251b3b82.png" alt="Card" className="primary-action-img right-img" />
      </div>
      <div className="action-card">
        <div className="action-card-main single-center">
          <img src="/images/ieo.dd55809c.png" alt="IEO Subscribe" className="primary-action-img" />
          <span>IEO Subscribe</span>
        </div>
      </div>
    </div>
  );
};

export default PrimaryActions; 