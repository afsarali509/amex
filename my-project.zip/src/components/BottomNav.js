import React from 'react';
import './BottomNav.css';
import { FaHome, FaChartBar, FaGlobe, FaChartPie, FaUser, FaSignInAlt } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

const BottomNav = () => {
  const navigate = useNavigate();
  const USERDATA = JSON.parse(sessionStorage.getItem("USER-INFO"));
  const navItems = [
    { icon: <FaHome />, label: 'Home', active: true, link: '/' },
    { icon: <FaChartBar />, label: 'Markets', link: '/' },
    { icon: <FaGlobe />, label: 'Exchange', link: '/' },
    { icon: <FaChartPie />, label: 'Options', link: '/' },
    // ...(USERDATA ? { 
    //   icon: <FaUser />, label: 'Profile', link: '/dashboard' 
    // } : {
    //    icon: <FaSignInAlt />, label: 'Login', link: '/login' 
    // })
    
    // ,
    ,
  ];

  const handleClick = (link='/') => {
    try {
      navigate(link);
    } catch (error) {
      navigate('/')
    }
  }

  return (
    <div className="bottom-nav">
      {/* {navItems.map((item, index) => (
        <div key={index} className={`nav-item ${item.active ? 'active' : ''}`} onClick={() => handleClick(item.link)}>
          {item.icon}
          <span>{item.label}</span>
        </div>
      ))} */}

      <div className={`nav-item active`} onClick={() => handleClick('/')}>
        <FaHome />
        <span>Home</span>
      </div>

      <div className={`nav-item active`} onClick={() => handleClick('/buy-coin')}>
        <FaChartBar />
        <span>Buy</span>
      </div>

      <div className={`nav-item active`} onClick={() => handleClick('/sell-coin')}>
        <FaGlobe />
        <span>Sell</span>
      </div>
      {USERDATA ? (<>
        <div className={`nav-item active`} onClick={() => handleClick('/dashboard')}>
          <FaUser />
          <span>Profile</span>
        </div>
      </>):(<>
        <div className={`nav-item active`} onClick={() => handleClick('/login')}>
          <FaSignInAlt />
          <span>Login</span>
        </div>
      </>)}

    </div>
  );
};

export default BottomNav; 