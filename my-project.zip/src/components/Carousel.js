import React from 'react';
import Carousel from 'react-bootstrap/Carousel';

const images = [
  '/images/banner1.jpg',
  '/images/banner2.jpg',
];

const BootstrapCarousel = () => {
  return (
    <Carousel>
      {images.map((src, idx) => (
        <Carousel.Item key={idx}>
          <img
            className="d-block w-100"
            src={src}
            alt={`slide-${idx}`}
            style={{ borderRadius: '10px' }}
          />
        </Carousel.Item>
      ))}
    </Carousel>
  );
};

export default BootstrapCarousel; 