import React, { useEffect, useState } from 'react';
import './MarketTicker.css';
import { list } from "../controllers/front/coinsControllers";
const MarketTicker = () => {
  const [marketRates, setMarketRates] = useState([]);

  const getCoinData = async () =>{
    try {
      const options = {}
      const res = await list(options);
      if(res?.status === true){
        setMarketRates(res?.result || []);
      }
    } catch (error) {
      
    }
  }

  useEffect(() => {
    let timeoutId;
    let isUnmounted = false;

    const poll = async () => {
      await getCoinData();
      if (!isUnmounted) {
        timeoutId = setTimeout(poll, 10000);
      }
    };
    poll();
    return () => {
      isUnmounted = true;
      clearTimeout(timeoutId);
    };
  }, []);
  // const marketRates = [
  //   { name: 'BTC', price: '105699.51', change: '+0.44%', vol: 'Vol 0.21 K', positive: true },
  //   { name: 'ETH', price: '2448.18', change: '+0.42%', vol: 'Vol 10.28 K', positive: true },
  //   { name: 'TRX', price: '0.273627', change: '+0.42%', vol: 'Vol 3405.40 K', positive: true },
  //   { name: 'XAU', price: '3295.439834', change: '-0.09%', vol: 'Vol 60.82 K', positive: false },
  //   { name: 'XAG', price: '35.490982', change: '-0.18%', vol: 'Vol 270.37 K', positive: false },
  // ];
  return (
    <div className="market-ticker">
      <div className="market-table-section">
        <div className="market-table-title">Market Rates</div>
        <div className="market-table-wrapper">
          <table className="market-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Price</th>
                <th>Price Volatility</th>
              </tr>
            </thead>
            <tbody>
              {marketRates.map((rate, idx) => (
                <tr key={idx}>
                  <td>{rate.coin}</td>
                  <td>{rate.current_price}<div className="market-table-vol">{rate?.vol}</div></td>
                  <td>
                    {rate.price_change_percentage_24h ? (
                      <span className={`market-table-change ${rate.price_change_percentage_24h > 0 ? 'positive' : 'negative'}`}>{parseFloat(rate?.price_change_percentage_24h)?.toFixed(2)} %</span>
                    ):'--'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default MarketTicker; 