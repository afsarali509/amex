import React from 'react';
import './WelcomeBar.css';
import { FaVolumeUp } from 'react-icons/fa';
import { BsGridFill } from 'react-icons/bs';

const WelcomeBar = () => {
  return (
    <div className="welcome-bar">
      <FaVolumeUp color="#4a90e2" />
      <p className="welcome-text">Welcome to digital trading platform</p>
      <BsGridFill color="#4a90e2" />
    </div>
  );
};

export default WelcomeBar; 