import React from 'react';
import { NavLink } from 'react-router-dom';
import './admin.css';

const Sidebar = () => (
  <nav className="admin-sidebar">
    <h2>Admin Panel</h2>
    <ul>
      <li>
        <NavLink to="/admin/dashboard" className={({ isActive }) => isActive ? 'active' : ''}>Dashboard</NavLink>
      </li>
      <li>
        <NavLink to="/admin/listing" className={({ isActive }) => isActive ? 'active' : ''}>Listing</NavLink>
      </li>
      <li>
        <NavLink to="/admin/add" className={({ isActive }) => isActive ? 'active' : ''}>Add/Edit</NavLink>
      </li>
    </ul>
  </nav>
);

export default Sidebar; 