import React from 'react';

const mockData = [
  { id: 1, name: 'Bitcoin', symbol: 'BTC', price: '$60,000' },
  { id: 2, name: 'Ethereum', symbol: 'ETH', price: '$3,000' },
  { id: 3, name: 'Solana', symbol: 'SOL', price: '$150' },
];

const Listing = () => {
  return (
    <div>
      <h1>Listing</h1>
      <table className="admin-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Symbol</th>
            <th>Price</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {mockData.map((item) => (
            <tr key={item.id}>
              <td>{item.id}</td>
              <td>{item.name}</td>
              <td>{item.symbol}</td>
              <td>{item.price}</td>
              <td>
                <button>Edit</button>
                <button>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Listing; 