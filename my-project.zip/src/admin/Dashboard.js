import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'Mon', BTC: 60000, ETH: 3000 },
  { name: 'Tue', BTC: 61000, ETH: 3200 },
  { name: 'Wed', BTC: 59000, ETH: 3100 },
  { name: 'Thu', BTC: 62000, ETH: 3300 },
  { name: 'Fri', BTC: 63000, ETH: 3400 },
  { name: 'Sat', BTC: 64000, ETH: 3500 },
  { name: 'Sun', BTC: 65000, ETH: 3600 },
];

const Dashboard = () => {
  return (
    <div>
      <h1>Dashboard</h1>
      <div style={{ height: 400, background: '#f5f5f5', borderRadius: 8, padding: 24 }}>
        <ResponsiveContainer width="100%" height={350}>
          <LineChart data={data} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="BTC" stroke="#8884d8" strokeWidth={2} />
            <Line type="monotone" dataKey="ETH" stroke="#82ca9d" strokeWidth={2} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default Dashboard; 