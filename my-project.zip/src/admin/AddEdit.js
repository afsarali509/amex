import React, { useState } from 'react';

const AddEdit = () => {
  const [form, setForm] = useState({ name: '', symbol: '', price: '' });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Submitted! (No actual data handling yet)');
  };

  return (
    <div>
      <h1>Add / Edit Item</h1>
      <form className="admin-form" onSubmit={handleSubmit}>
        <label>
          Name:
          <input name="name" value={form.name} onChange={handleChange} required />
        </label>
        <label>
          Symbol:
          <input name="symbol" value={form.symbol} onChange={handleChange} required />
        </label>
        <label>
          Price:
          <input name="price" value={form.price} onChange={handleChange} required />
        </label>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default AddEdit; 