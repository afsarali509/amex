import React, { useState } from 'react';
import './login.css';
import { Link, useNavigate } from 'react-router-dom';
import { userRegistration, sendOTP } from '../controllers/front/usersController';
import MyToast from "../components/MyToast";

const Registration = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    country_code : "+91"
  });
  const [showOTPSection, setShowOTPSection] = useState(false);
  const [errors, setError]= useState("");
  const [showError, setShowError]= useState(false);

  const handleChange = async (e) => {
    try {
      const {name, value} = e.target;
      setFormData((pre)=>({
        ...pre,
        [name] : value
      }));
    } catch (error) {
      
    }
  }

  const onSubmit = async (e) =>{
    e.preventDefault();
    try {
      if(!formData?.country_code){
        setError("Please select country");
        setShowError(true);
      } else if (!formData?.name){
        setError("Name is required.");
        setShowError(true);
      } else if (!formData?.phone){
        setError("Mobile number is required.");
        setShowError(true);
      } else if (!formData?.email){
        setError("Email address is required.");
        setShowError(true);
      } else if (!formData?.password){
        setError("Password is required.");
        setShowError(true);
      } else if (!formData?.confirm_password){
        setError("Confirm password is required.");
        setShowError(true);
      } else if (formData?.password !== formData?.confirm_password){
        setError("Password and confirm password is not match.");
        setShowError(true);
      } else {
        if(!formData?.otp){
          const res = await sendOTP({email : formData.email});
          if(res.status === true){
            setShowOTPSection(true);
          }else{
            setError(`${res?.message}`);
            setShowError(true);
          }
        } else{
          const params = {
              name : formData?.name,
              country_code : formData?.country_code,
              phone : formData?.phone,
              email : formData?.email,
              password : formData?.password,
              otp : formData?.otp,
            }
            const resp = await userRegistration(params);
            if(resp.status === true){
              setError("Your account is created successfully.");
              setShowError(true);
              navigate('/login');
            } else{
              setError(`${resp?.message}`);
              setShowError(true);
            }
        }
      }
    } catch (error) {
      console.log('error : ',error);
      setError(`Something went wrong! Please try again.`);
      setShowError(true);
    }
  }

  return (<>
    <div className="login-container">
      <div className="login-header-row">
        <span role="img" aria-label="india-flag" className="login-flag">AMEX</span>
        <span className="login-close" onClick={()=>navigate('/')}>&times;</span>
      </div>
      <h2 className="login-title">Registration</h2>
      {/* <div className="login-tabs">
        <button className={tab === 'mail' ? 'active' : ''} onClick={() => setTab('mail')}>With Email ID</button>
        <button className={tab === 'mobile' ? 'active' : ''} onClick={() => setTab('mobile')}>With Mobile Number</button>
      </div> */}
      
      <form className="login-form" onSubmit={onSubmit}>
        <label>Name</label>
        <input type="text" name='name' id='name' value={formData?.name} onChange={handleChange} disabled={showOTPSection} placeholder="Please enter your name" />
        <label>Country</label>
        <select name='country_code' id='country_code' onChange={handleChange} disabled={showOTPSection}>
          <option value="+91" selected={formData?.country_code === '+91'}>+91 India</option>
          <option value="+971" selected={formData?.country_code === '+971'} >+971 UAE</option>
        </select>
        <label>Mobile number</label>
        <input type="number" name='phone' id='phone' value={formData?.phone} onChange={handleChange} disabled={showOTPSection} placeholder="Please enter your mobile number" />
        <label>Email address</label>
        <input type="email" name='email' id='email' value={formData?.email} onChange={handleChange} disabled={showOTPSection} placeholder="Please enter your email address" />
        <label>New Password</label>
        <input type="password" name='password' id='password' value={formData?.password} onChange={handleChange} disabled={showOTPSection} placeholder="Please enter new password" />

        <label>Confirm Password</label>
        <input type="password" name='confirm_password' id='confirm_password' value={formData?.confirm_password} disabled={showOTPSection} onChange={handleChange} placeholder="Please enter the confirm password" />

        {showOTPSection && (<>
          <div className='login-form'>
            <label>One Time Password (OTP)</label>
            <input type="number" name='otp' id='otp' value={formData?.otp} onChange={handleChange} placeholder="Please enter one time password." />
          </div>
      </>)}
        <button type="submit" className="login-btn">REGISTER NOW</button>
      </form>
    
      <div className="login-links-row">
        <Link to={'/login'} className="login-link">Already have an account, Login!</Link>
      </div>
    </div>
    <MyToast show={showError} setShow={setShowError} msg={errors}/>
  </>);
};

export default Registration; 