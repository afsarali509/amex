import React from 'react';
import { FaChevronRight } from 'react-icons/fa';
import './dashboard.css';

const assets = [
  { symbol: 'BTC' },
  { symbol: 'ETH' },
  { symbol: 'TRX' },
  { symbol: 'USDT' },
  { symbol: 'PANDA' },
  { symbol: 'XAU' },
  { symbol: 'UKOIL' },
];

const Portfolio = () => {
  return (
    <div className="portfolio-container">
      <div className="portfolio-header">
        <span className="portfolio-close">&times;</span>
        <span className="portfolio-title">Portfolio</span>
      </div>
      <div className="portfolio-tabs">
        <span className="portfolio-tab active">Exchange</span>
      </div>
      <div className="portfolio-list">
        {assets.map((asset) => (
          <div className="portfolio-card" key={asset.symbol}>
            <div className="portfolio-card-row">
              <span className="portfolio-symbol">{asset.symbol}</span>
              <FaChevronRight className="portfolio-arrow" />
            </div>
            <div className="portfolio-card-info">
              <div>
                <div className="portfolio-label">Available</div>
                <div className="portfolio-value">0</div>
              </div>
              <div>
                <div className="portfolio-label">Freeze</div>
                <div className="portfolio-value">0</div>
              </div>
              <div>
                <div className="portfolio-label">Convert into($)</div>
                <div className="portfolio-value bold">0.0000</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Portfolio; 