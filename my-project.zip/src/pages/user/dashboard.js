import React from 'react';
import '../login.css';
import { useNavigate } from 'react-router-dom';
import BottomNav from '../../components/BottomNav';
import { FaUserCircle, FaWallet, FaExchangeAlt, FaFileAlt, FaUserCheck, FaEnvelope, FaKey, FaHeadset, FaFileContract, FaMobileAlt, FaUserPlus, FaSignOutAlt, FaArrowRight } from 'react-icons/fa';

const userProfile = {
  name: 'John Doe',
  email: 'john.doe@example.com',
  joined: '2023-01-15',
  avatar: '/images/india.png',
};

const transactions = [
  { id: 1, date: '2024-06-01', type: 'Deposit', amount: '+500 USDT', status: 'Completed' },
  { id: 2, date: '2024-06-03', type: 'Trade', amount: '-200 USDT', status: 'Completed' },
  { id: 3, date: '2024-06-05', type: 'Withdraw', amount: '-100 USDT', status: 'Pending' },
];

const coinsHistory = [
  { coin: 'BTC', change: '+0.01', date: '2024-06-01' },
  { coin: 'ETH', change: '-0.2', date: '2024-06-03' },
  { coin: 'TRX', change: '+100', date: '2024-06-05' },
];

const Dashboard = () => {
  const navigate = useNavigate();
  const handleLogout = async () => {
    try {
      sessionStorage.clear();
      navigate('/login');
    } catch (error) {
      
    }
  }
  return (
    <div className="dashboard-container">
      <div className="dashboard-title">My Account</div>
      <div className="dashboard-card">
        <div className="dashboard-profile">
          <FaUserCircle className="dashboard-avatar" />
          <div className="dashboard-profile-info">
            <div className="dashboard-profile-id">ID:9802023</div>
            <div className="dashboard-profile-assets">Assets~$0.00</div>
            <div className="dashboard-profile-vip">VIP1</div>
          </div>
        </div>
        <div className="dashboard-actions">
          <div className="dashboard-action"><FaWallet /><span>Deposit</span></div>
          <div className="dashboard-action"><FaExchangeAlt /><span>Withdraw</span></div>
          <div className="dashboard-action"><FaExchangeAlt /><span>Convert</span></div>
          <div className="dashboard-action"><FaFileAlt /><span>Portfolio</span></div>
        </div>
      </div>
      <div className="dashboard-menu-group">
        <div className="dashboard-menu-item"><FaFileAlt /><span>Transaction history</span><FaArrowRight className="dashboard-menu-arrow" /></div>
        <div className="dashboard-menu-item"><FaUserCheck /><span>Verification status</span><FaArrowRight className="dashboard-menu-arrow" /></div>
        <div className="dashboard-menu-item"><FaEnvelope /><span>Bind email</span><FaArrowRight className="dashboard-menu-arrow" /></div>
        <div className="dashboard-menu-item"><FaKey /><span>Update the password</span><FaArrowRight className="dashboard-menu-arrow" /></div>
      </div>
      <div className="dashboard-menu-group">
        <div className="dashboard-menu-item"><FaHeadset /><span>Customer support</span><FaArrowRight className="dashboard-menu-arrow" /></div>
        <div className="dashboard-menu-item"><FaFileContract /><span>AMEX.US User Agreement</span><FaArrowRight className="dashboard-menu-arrow" /></div>
        <div className="dashboard-menu-item"><FaMobileAlt /><span>Download APP</span><FaArrowRight className="dashboard-menu-arrow" /></div>
        <div className="dashboard-menu-item"><FaUserPlus /><span>Invite</span><FaArrowRight className="dashboard-menu-arrow" /></div>
      </div>
      <div className="dashboard-menu-group">
        <div className="dashboard-menu-item logout" onClick={handleLogout}><FaSignOutAlt /><span>Log out</span></div>
      </div>
      <BottomNav />
    </div>
  );
};

export default Dashboard; 