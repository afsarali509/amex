import React, { useEffect, useState } from 'react';
import './login.css';
import { Link, useLocation, useNavigate } from 'react-router-dom';

import MyToast from '../components/MyToast';
import {list as coinList, sellRequest, buyRequest} from "../controllers/front/coinsControllers";

const TradeRequest = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const USERDATA = JSON.parse(sessionStorage.getItem("USER-INFO"));
  const TOKEN = sessionStorage.getItem("USER-TOKEN");
  const [formData, setFormData] = useState({
    email : USERDATA?.email || "",
    phone : USERDATA?.phone || ""
  });
  const [shotMsg, setShowMsg] = useState(false)
  const [errMsg, setErrMsg] = useState(false);
  const [coinListData, setCoinListData] = useState([]);

  const handleClose = async () => {
    navigate('/');
  }

  const getCoinData = async () =>{
      try {
        const options = {}
        const res = await coinList(options);
        if(res?.status === true){
          setCoinListData(res?.result || []);
        }
      } catch (error) {
        
      }
    }
  
    useEffect(()=>{
      getCoinData();
    },[])

  const onSubmit = async (e) =>{
    e.preventDefault();
    try {
      const formData = new FormData(e.target);
      if(!formData.get('coin')){
        setErrMsg(`Coin is required.`);
        setShowMsg(true);
      } else if(!formData.get('amount')){
        setErrMsg('Amount is required.');
        setShowMsg(true);
      } else if(!formData.get('email')){
        setErrMsg('Email is required.');
        setShowMsg(true);
      } else if(!formData.get('phone')){
        setErrMsg('phone is required.');
        setShowMsg(true);
      } else{
        const params = {
          coin_id : formData.get('coin'),
          amount : formData.get('amount'),
          email : formData.get('email'),
          phone : formData.get('phone'),
        }
        if(location.pathname === '/buy-coin'){
          const res = await buyRequest(params);
          if(res?.status === true){
            setErrMsg(`Thank for purchases coin. Our team will contact you.`);
            setShowMsg(true);
          } else{
            setErrMsg(`${res.message}`);
            setShowMsg(true);
          }
        } else{
          const res = await sellRequest(params);
          if(res?.status === true){
            setErrMsg(`Thank for business with us. Our team will contact you.`);
            setShowMsg(true);
          } else{
            setErrMsg(`${res.message}`);
            setShowMsg(true);
          }
        }
        console.log('params : ', params);
      }      
    } catch (error) {
      console.log('error : ', error);
      setErrMsg(`Something went wrong! Please try again.`);
      setShowMsg(true);
    }
  }

  const handleChange = async (e) => {
    const { name, value } = e.target;
    setFormData((pre)=>({
      ...pre,
      [name] : value
    }))
  }
  return (
    <div className="login-container">
      <div className="login-header-row">
        <span role="img" aria-label="india-flag" className="login-flag">AMEX</span>
        <span className="login-close" onClick={handleClose}>&times;</span>
      </div>
      {/* <h2 className="login-title">Purchases Request</h2> */}
      <div className="login-tabs">
        <button className={location.pathname === '/buy-coin' ? 'active' : ''} onClick={() => navigate('/buy-coin')}>Buy Coin</button>
        <button className={location.pathname === '/sell-coin' ? 'active' : ''} onClick={() => navigate('/sell-coin')}>Sell Coin</button>
      </div>
      <form className="login-form" onSubmit={onSubmit}>
        <select name='coin' id='coin' >
          <option value="" selected disabled>Select Coin</option>
          {(coinListData && coinListData?.length > 0) && coinListData.map((item)=>(
            <option value={item?.coin_id}>{item?.coin}</option>
          )) }
        </select>

        <label>Amount</label>
        <input type="number" name='amount' id='amount' placeholder="Please enter your amount." />

        <label>Email</label>
        <input type="text" name='email' id='email' onChange={handleChange} value={formData?.email} readOnly={TOKEN?true:false} placeholder="Please enter your mobile/email" />

        <label>Mobile</label>
        <input type="number" name='phone' id='phone' onChange={handleChange} value={formData?.phone} readOnly={TOKEN?true:false} placeholder="Please enter your mobile/email" />

        <button type="submit" className="login-btn">Submit</button>
      </form>
      {/* <div className="login-links-row">
        <Link to={'/reset-password'} className="login-link">Forget the password?</Link>
        <Link to={'/registration'} className="login-link">Not registered yet?</Link>
      </div> */}
      <MyToast show={shotMsg} setShow={setShowMsg} msg={errMsg}/>
    </div>
  );
};

export default TradeRequest; 