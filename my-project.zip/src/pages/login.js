import React, { useEffect, useState } from 'react';
import './login.css';
import { Link, useNavigate } from 'react-router-dom';

import {login, verifyOTP} from "../controllers/front/usersController";
import MyToast from '../components/MyToast';

const Login = () => {
  const navigate = useNavigate();
  const USERDATA = JSON.parse(sessionStorage.getItem("USER-INFO"));
  const TOKEN = sessionStorage.getItem("USER-TOKEN");
  const [tab, setTab] = useState('email');
  const [country, setCountry] = useState('+91 India');
  const [formData, setFormData] = useState({});
  const [shotMsg, setShowMsg] = useState(false)
  const [errMsg, setErrMsg] = useState(false)

  const handleClose = async () => {
    navigate('/');
  }

  const onSubmit = async (e) =>{
    e.preventDefault();
    try {
      const formData = new FormData(e.target);
      if(tab === 'email' && !formData.get('email')){
        setErrMsg("Please enter your email address.");
        setShowMsg(true);
      } else if(tab === 'mobile' && !formData.get('phone')){
        setErrMsg("Please enter your mobile number.");
        setShowMsg(true);
      } else {
        const param = {
          ...(tab === 'email' ? {email : formData.get('email')
          }:{
            phone : formData.get('phone')
          }),
          password : formData.get('password')
        }
        const res = await login(param);
        if(res?.status === true){
          setErrMsg(`Welcome back ${res?.result?.name || res?.result?.email}`);
          setShowMsg(true);
          navigate('/dashboard');
        } else{
          setErrMsg(`${res?.message}`);
          setShowMsg(true);
        }
      }
      
    } catch (error) {
      console.log('error : ', error);
      setErrMsg(`Something went wrong! Please try again.`);
      setShowMsg(true);
    }
  }

  useEffect(()=>{
    if(USERDATA || TOKEN){
      navigate("/dashboard");
    }
  },[])
  return (
    <div className="login-container">
      <div className="login-header-row">
        <span role="img" aria-label="india-flag" className="login-flag">AMEX</span>
        <span className="login-close" onClick={handleClose}>&times;</span>
      </div>
      <h2 className="login-title">Welcome Log in</h2>
      <div className="login-tabs">
        <button className={tab === 'email' ? 'active' : ''} onClick={() => setTab('email')}>With Email ID</button>
        <button className={tab === 'mobile' ? 'active' : ''} onClick={() => setTab('mobile')}>With Mobile Number</button>
      </div>
      <form className="login-form" onSubmit={onSubmit}>
        {tab === 'email'?(<>
          <label>Email</label>
          <input type="text" name='email' id='email' placeholder="Please enter your email" />
        </>):(<>
          <label>Country</label>
          <select name='country_code' id='country_code' >
            <option value="+91" selected>+91 India</option>
            <option value="+1">+1 USA</option>
            <option value="+44">+44 UK</option>
          </select>
          <label>Mobile</label>
          <input type="number" name='phone' id='phone' placeholder="Please enter your mobile" />
        </>)}

        <label>Password</label>
        <input type="password" name='password' id='password' placeholder="Please enter the login password" />

        <button type="submit" className="login-btn">LOG IN</button>
      </form>
      <div className="login-links-row">
        <Link to={'/reset-password'} className="login-link">Forget the password?</Link>
        <Link to={'/registration'} className="login-link">Not registered yet?</Link>
      </div>
      <MyToast show={shotMsg} setShow={setShowMsg} msg={errMsg}/>
    </div>
  );
};

export default Login; 