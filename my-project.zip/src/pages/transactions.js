import React from 'react';
import './login.css';
import BottomNav from '../components/BottomNav';
import { useNavigate } from 'react-router-dom';

const transactions = [
  { id: 1, date: '2024-06-01', type: 'Deposit', amount: '+500 USDT', status: 'Completed' },
  { id: 2, date: '2024-06-03', type: 'Trade', amount: '-200 USDT', status: 'Completed' },
  { id: 3, date: '2024-06-05', type: 'Withdraw', amount: '-100 USDT', status: 'Pending' },
];

const Transactions = () => {
  const navigate = useNavigate();
  return (
    <div className="login-container" style={{ maxWidth: 800, minHeight: '100vh', paddingBottom: 80, display: 'flex', flexDirection: 'column' }}>
      <div style={{ margin: '24px 0 0 0', display: 'flex', alignItems: 'center' }}>
        <button
          onClick={() => navigate('/dashboard')}
          style={{
            background: '#e3eefd',
            border: 'none',
            color: '#3949ab',
            fontSize: 28,
            display: 'flex',
            alignItems: 'center',
            borderRadius: 24,
            padding: '8px 18px',
            boxShadow: '0 2px 8px #b3c6f7',
            cursor: 'pointer',
            fontWeight: 500,
            transition: 'background 0.2s',
            marginBottom: 10
          }}
          onMouseOver={e => (e.currentTarget.style.background = '#b3c6f7')}
          onMouseOut={e => (e.currentTarget.style.background = '#e3eefd')}
          aria-label="Back to Dashboard"
        >
          <span style={{ fontSize: 32, display: 'flex', alignItems: 'center' }}>←</span>
        </button>
      </div>
      <h2 className="login-title" style={{ marginBottom: 30 }}>Transaction History</h2>
      <div style={{ overflowX: 'auto', flex: 1 }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', background: '#f4f8fb', borderRadius: 8 }}>
          <thead>
            <tr style={{ background: '#b3c6f7' }}>
              <th style={{ padding: 10, fontWeight: 500, color: '#1a237e' }}>Date</th>
              <th style={{ padding: 10, fontWeight: 500, color: '#1a237e' }}>Type</th>
              <th style={{ padding: 10, fontWeight: 500, color: '#1a237e' }}>Amount</th>
              <th style={{ padding: 10, fontWeight: 500, color: '#1a237e' }}>Status</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map(tx => (
              <tr key={tx.id} style={{ borderBottom: '1px solid #e3eefd' }}>
                <td style={{ padding: 10 }}>{tx.date}</td>
                <td style={{ padding: 10 }}>{tx.type}</td>
                <td style={{ padding: 10 }}>{tx.amount}</td>
                <td style={{ padding: 10, color: tx.status === 'Completed' ? '#00b894' : '#d63031' }}>{tx.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <BottomNav />
    </div>
  );
};

export default Transactions; 