import Header from '../components/Header';
import BootstrapCarousel from '../components/Carousel';
import WelcomeBar from '../components/WelcomeBar';
import PrimaryActions from '../components/PrimaryActions';
import SecondaryActions from '../components/SecondaryActions';
import MarketTicker from '../components/MarketTicker';
import BottomNav from '../components/BottomNav';
import '../App.css'; // or create a new Home.css if preferred

const Home = () => {
  return (
    <div className="home-container">
      {/* <Header /> */}
      <main className="home-main">
        {/* <h1 className="home-title">Welcome to Digital Trading Platform</h1> */}
        <BootstrapCarousel />
        <WelcomeBar />
        <div className="home-section">
          <PrimaryActions />
        </div>
        <div className="home-section">
          <SecondaryActions />
        </div>
        <div className="home-section">
          <MarketTicker />
        </div>
      </main>
      <BottomNav />
    </div>
  );
};

export default Home;
