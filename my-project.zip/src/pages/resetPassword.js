import React, { useState } from 'react';
import './login.css';
import { Link, useNavigate } from 'react-router-dom';
import {forgotPassword, resetPassword} from "../controllers/front/usersController";
import MyToast from "../components/MyToast";
const ResetPassword = () => {
  const navigate = useNavigate();
  const [tab, setTab] = useState('mail');
  const [country, setCountry] = useState('+91 India');
  const [showError, setShowError] = useState(false)
  const [error, setError]=useState("");
  const [isOTPSent, setIsOTPSent] = useState(false);
  const [formData, setFormData] = useState({
    email : "",
    otp : ""
  })
  const [ isOTPSend, setIsOTPSend] = useState(false);
  const handleSubmit = async (e) => {
    e.preventDefault();
    if(!isOTPSend){
      forgotUserPassword();
    } else {
      resetUserPassword();
    }
  }

  const forgotUserPassword = async ()=>{
    try {
      if(!formData?.email){
        setError('Email address is required.');
        setShowError(true);
      } else {
        const option = {
          email : formData?.email
        }
        const res = await forgotPassword(option);
        if(res?.status === true){
          setError(`One Time Password (OTP) is sent to ${formData?.email}.`);
          setShowError(true);
          setIsOTPSent(true);
        } else {
          setError(`${res?.message}`);
          setShowError(true);
        }
      }
    } catch (error) {
      console.log('error : ',error);
      setError(`Something went wrong! Please try after sometime.`);
      setShowError(true);
    }
  }

  const resetUserPassword = async ()=>{
    try {
      if(!formData?.email){
        setError('Email address is required.');
        setShowError(true);
      } else if(!formData?.otp){
        setError('One Time Password (OTP) is required.');
        setShowError(true);
      } else if(!formData?.password){
        setError('Password is required.');
        setShowError(true);
      } else if(!formData?.confirm_password){
        setError('Confirm password is required.');
        setShowError(true);
      } else if(formData?.password !== formData?.confirm_password){
        setError('Password and confirm password not match..');
        setShowError(true);
      } else {
        const options = {
          email : formData?.email,
          otp : formData?.otp,
          password : formData?.password
        }
        const res = await resetPassword(options);
        if(res?.status === true){
          setError(`Password reset successfully.`);
          setShowError(true);
          navigate('/login')
        } else {
          setError(`${res?.message}`);
          setShowError(true);
        }
      }
    } catch (error) {
      setError(`Something went wrong! Please try after sometime.`);
      setShowError(true);
    }
  }

  const handleChange = async (e) => {
    try {
      const {name, value} = e.target;
      setFormData((pre)=>({
        ...pre,
        [name] : value
      }))
    } catch (error) {
      
    }
  }
  return (
    <div className="login-container">
      <div className="login-header-row">
        <span role="img" aria-label="india-flag" className="login-flag">AMEX</span>
        <span className="login-close" onClick={()=>navigate('/')}>&times;</span>
      </div>
      <h2 className="login-title">Reset Password</h2>
      {/* <div className="login-tabs">
        <button className={tab === 'mail' ? 'active' : ''} onClick={() => setTab('mail')}>With Email ID</button>
        <button className={tab === 'mobile' ? 'active' : ''} onClick={() => setTab('mobile')}>With Mobile Number</button>
      </div> */}
      <form className="login-form" onSubmit={handleSubmit}>
        <label>Email Address</label>
        <input type="email" name='email' id='email' value={formData?.email} onChange={handleChange} disabled={isOTPSent} placeholder="Please enter your email number" />
        {isOTPSent && (<>
          <label>One Time Password</label>
          <input type="number" name='otp' id='otp' value={formData?.otp} onChange={handleChange} placeholder="Please enter your email number" />

          <label>Password</label>
          <input type="password" name='password' id='password' value={formData?.password} onChange={handleChange} placeholder="Please enter your email number" />

          <label>Confirm Password</label>
          <input type="password" name='confirm_password' id='confirm_password' value={formData?.confirm_password} onChange={handleChange} placeholder="Please enter your email number" />
        </>)}

        {/* <label>Password</label>
        <input type="password" placeholder="Please enter the login password" /> */}
        {!isOTPSent ? (<>
          <button type="button" className="login-btn" onClick={forgotUserPassword}>RESET PASSWORD</button>
        </>):(<>
          <button type="button" className="login-btn" onClick={resetUserPassword}>Submit</button>
        </>)}
      </form>
      <div className="login-links-row">
        <Link to="/login" className="login-link">Back to Login!</Link>
      </div>
      <MyToast show={showError} setShow={setShowError} msg={error} />
    </div>
  );
};

export default ResetPassword; 