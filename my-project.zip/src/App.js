import './App.css';
import {
  Route,
  Routes,
  Navigate,
  useLocation
} from "react-router-dom";

import Home from './pages/home';
import Login from './pages/login';
import Registration from './pages/registration';
import ResetPassword from './pages/resetPassword';
// import Dashboard from './pages/dashboard';
import Transactions from './pages/transactions';
import Coins from './pages/coins';

// import AdminLogin from "./admin/login";
// import Sidebar from './admin/Sidebar';
// import AdminDashboard from './admin/Dashboard';
// import Listing from './admin/Listing';
// import AddEdit from './admin/AddEdit';
import UserDashboard from './pages/user/dashboard';
import Portfolio from './pages/user/portfolio';
import TradeRequest from "./pages/tradeRequest";

// function AdminLayout() {
//   const location = useLocation();

//   return (
//     <div className="admin-container">
//       {!["/admin/login"].includes(location.pathname) && <Sidebar /> }
//       <div className="admin-content">
//         <Routes>
//           <Route path="login" element={<AdminLogin />} />
//           <Route path="dashboard" element={<AdminDashboard />} />
//           <Route path="listing" element={<Listing />} />
//           <Route path="add" element={<AddEdit />} />
//           <Route path="edit/:id" element={<AddEdit />} />
//           <Route path="*" element={<Navigate to="login" replace />} />
//         </Routes>
//       </div>
//     </div>
//   );
// }

function App() {
   const user = JSON.parse(sessionStorage.getItem("USER-INFO"));
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/registration" element={<Registration />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/dashboard" element={<UserDashboard />} />
      <Route path="/transactions" element={<Transactions />} />
      <Route path="/coins" element={<Coins />} />
      <Route path="/portfolio" element={<Portfolio />} />
      {/* <Route path="/admin/*" element={<AdminLayout />} /> */}
      
      <Route path="/buy-coin" element={<TradeRequest />} />
      <Route path="/sell-coin" element={<TradeRequest />} />
    </Routes>
  );
}

export default App; 