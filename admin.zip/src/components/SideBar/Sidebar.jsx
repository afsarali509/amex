import React, { useEffect, useState } from "react";
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Collapse } from "antd";
import "./SideBar.css";
import { faBarsStaggered, faCogs, faGreaterThan } from '@fortawesome/free-solid-svg-icons';
import { faCircle, faCircleUser } from '@fortawesome/free-regular-svg-icons';
import { faCreditCard } from '@fortawesome/free-regular-svg-icons';
import { faHouse } from '@fortawesome/free-solid-svg-icons';
import { usePermissions, PermissionContext } from "../../controllers/PermissionContext";

const { Panel } = Collapse;

const SidebarItem = ({ to, icon, name, isOpen, className }) => (
  <NavLink to={to} className={`link ${className}`} activeClassName="active">
    <div className="icon">{icon}</div>
    <div style={{ display: isOpen ? "block" : "none" }} className="link_text">
      {name}
    </div>
  </NavLink>
);

const Sidebar = ({ children }) => {
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(true);
  const navigate = useNavigate();
  const handleCollapseToggle = () => {
    setIsOpen(!isOpen);
  };
  
  const PERMISSION = usePermissions("FULL");
  const { refetchPermissions } = React.useContext(PermissionContext);
  const user = JSON.parse(sessionStorage.getItem("ADMIN-INFO"));
  const [PERMISSIONDATA, setPermissionData] = useState('');

  const getFullPermission = async () => {
    try {
      if (PERMISSION?.permissions && Object.keys(PERMISSION?.permissions).length > 0) {
        setPermissionData(PERMISSION?.permissions);
      } else if (PERMISSION?.fullAccess === 'Y') {
        setPermissionData({}); // For Super Admin
      } else if (typeof refetchPermissions === 'function') {
        await refetchPermissions();
      }
    } catch (error) {
      console.error('Error in getFullPermission:', error);
    }
  };

  useEffect(() => {
    getFullPermission();
  }, [refetchPermissions]);

  // Check if permissions are loaded
  const hasPermissions = user?.admin_type === 'Super Admin' || 
    (PERMISSIONDATA && typeof PERMISSIONDATA === 'object' && Object.keys(PERMISSIONDATA).length > 0);

  if (!hasPermissions) {
    return (
      <div className={`container-fluid side_bar_main_div ${isOpen ? "sidebar-open" : "sidebar-closed"}`}>
        <div style={{ width: isOpen ? "300px" : "70px", position: "relative" }} className="sidebar">
          <div className="top_section">
            <img src={`/logo.png`} className="sidebar_logo" alt="Logo" style={{
              display: isOpen ? "block" : "none",
              height: "50px",
              width: "auto",
            }} />
            <div style={{ marginLeft: isOpen ? "130px" : "0px" }} className="bars">
              <FontAwesomeIcon icon={faBarsStaggered} onClick={handleCollapseToggle} />
            </div>
          </div>
          <div className="my_sidebar_all_section">
            <SidebarItem to="/dashboard" icon={<FontAwesomeIcon icon={faHouse} />} name="Dashboard" isOpen={isOpen} />
          </div>
        </div>
        <main>{children}</main>
      </div>
    );
  }

  return (
    <div className={`container-fluid side_bar_main_div ${isOpen ? "sidebar-open" : "sidebar-closed"}`}>
      <div style={{ width: isOpen ? "300px" : "70px", position: "relative" }} className="sidebar">
        <div className="top_section">
          <img src={`/logo.png`} className="sidebar_logo" alt="Logo" style={{
            display: isOpen ? "block" : "none",
            height: "50px",
            width: "auto",
          }} />
          <div style={{ marginLeft: isOpen ? "130px" : "0px" }} className="bars">
            <FontAwesomeIcon icon={faBarsStaggered} onClick={handleCollapseToggle} />
          </div>
        </div>
        <div className="my_sidebar_all_section">
          <SidebarItem to="/dashboard" icon={<FontAwesomeIcon icon={faHouse} />} name="Dashboard" isOpen={isOpen} />

          {/* {user?.admin_type === 'Super Admin' && (
            <Collapse accordion className="my_collapse_icon">
              <Panel
                header={
                  <React.Fragment>
                    <FontAwesomeIcon icon={faCircleUser} className="sidebar_collapse_iohomeoutline" />
                    <span className={`sidebar_collapse_iohomeoutline_categoires ${isOpen ? "visible" : "hidden"}`}> Accounts </span>
                  </React.Fragment>
                }
                key="categories"
                className={`side_bar_categories ${isOpen ? "arrow-visible" : "arrow-hidden"}`}
              >
                <SidebarItem to="/sub-admin/list" icon={<FontAwesomeIcon icon={faCircle} />} name="Sub Admin" isOpen={isOpen} />
              </Panel>
            </Collapse>
          )} */}

            <Collapse accordion className="my_collapse_icon">
              <Panel
                header={
                  <React.Fragment>
                    <FontAwesomeIcon icon={faCreditCard} className="sidebar_collapse_iohomeoutline" />
                    <span className={`sidebar_collapse_iohomeoutline_categoires ${isOpen ? "visible" : "hidden"}`}> Users </span>
                  </React.Fragment>
                }
                key="categories"
                className={`side_bar_categories ${isOpen ? "arrow-visible" : "arrow-hidden"}`}
              >
                <SidebarItem to="/users/list" icon={<FontAwesomeIcon icon={faCircle} />} name="List" isOpen={isOpen} />
              </Panel>
            </Collapse>

            <Collapse accordion className="my_collapse_icon">
              <Panel
                header={
                  <React.Fragment>
                    <FontAwesomeIcon icon={faCreditCard} className="sidebar_collapse_iohomeoutline" />
                    <span className={`sidebar_collapse_iohomeoutline_categoires ${isOpen ? "visible" : "hidden"}`}> Coin </span>
                  </React.Fragment>
                }
                key="categories"
                className={`side_bar_categories ${isOpen ? "arrow-visible" : "arrow-hidden"}`}
              >
                <SidebarItem to="/coin/list" icon={<FontAwesomeIcon icon={faCircle} />} name="List" isOpen={isOpen} />
              </Panel>
            </Collapse>

            <Collapse accordion className="my_collapse_icon">
              <Panel
                header={
                  <React.Fragment>
                    <FontAwesomeIcon icon={faCreditCard} className="sidebar_collapse_iohomeoutline" />
                    <span className={`sidebar_collapse_iohomeoutline_categoires ${isOpen ? "visible" : "hidden"}`}> Request </span>
                  </React.Fragment>
                }
                key="categories"
                className={`side_bar_categories ${isOpen ? "arrow-visible" : "arrow-hidden"}`}
              >
                <SidebarItem to="/request/list" icon={<FontAwesomeIcon icon={faCircle} />} name="List" isOpen={isOpen} />
              </Panel>
            </Collapse>

          <SidebarItem
            icon={
              <img
                src={`./logo.png`}
                alt=""
                className="user_profile_pic_sidebar"
                onClick={handleCollapseToggle}
                width="100px"
              />
            }
            to='javaScript:void(0)'
            name={
              <div className="sidebar_profile_main_content_section" onClick={() => navigate("/sub-admin/addeditdata", { state: user })} >
                <React.Fragment>
                  <div className="sidebar_profile_main_content">
                    <div className="user_profile_pic_Admin_name">
                      <span className="user_profile_pic_Admin_panel">
                        {`${user?.name}`}
                      </span>
                      <br />
                      <span className="user_profile_pic_Admin_panel_">
                        Admin
                      </span>
                    </div>
                  </div>
                </React.Fragment>
                <React.Fragment>
                  <FontAwesomeIcon icon={faGreaterThan} className="side_bar_fagreaterthan"
                    onClick={handleCollapseToggle} />
                </React.Fragment>
              </div>
            }
            isOpen={isOpen}
            className="custom_profile_class_productList"
          />
        </div>
      </div>
      <main>{children}</main>
    </div>
  );
};

export default Sidebar;
