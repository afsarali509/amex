import React, { useEffect, useState } from "react";
import "./App.css";
import { BrowserRouter as Router, Route, Routes, useLocation, useNavigate } from "react-router-dom";

import LoginPage from "./components/LoginPage/LoginPage.js";
import ResetPassword from "./components/LoginPage/ResetPassword.js";
import Sidebar from "./components/SideBar/Sidebar.jsx";
import Dashboard from "./pages/DashBaord/Dashboard.jsx";
import SubAdminList from './pages/Accounts/SubAdmin/List.js'
import SubAdminAddEditData from './pages/Accounts/SubAdmin/AddEditData.js'

import Coin from "./pages/v1/coin/List.js";
import AddEditCoin from "./pages/v1/coin/AddEditData.js";

import UsersList from "./pages/v1/users/List.js";
import AddEditUsers from "./pages/v1/users/AddEditData.js";

import RequestList from "./pages/v1/request/List";


const App = () => {
  const location = useLocation();
  const navigate = useNavigate();
  
  
  
  const checkAuthentication = async () => {
    const token = sessionStorage.getItem("TOKEN");

    if (!["/", "/login", "/reset-password"].includes(location?.pathname)) {
      if (!token) {
        navigate("/");
      } else {
        if(location?.pathname === "/dashboard"){
          // refetchPermissions();
        }
        // fetchUserInfo();
      }
    }
  };
  useEffect(() => {
    checkAuthentication();
    // getFullPermission();
  }, [location]);
  const user = JSON.parse(sessionStorage.getItem("ADMIN-INFO"));
  return (
    <div className="App">
        <Routes>
          <Route path="/" element={<LoginPage />} />
          <Route path="/reset-password" element={<ResetPassword />} />
          <Route path="/dashboard" element={ <Sidebar> <Dashboard /> </Sidebar> } />
          <Route path="/sub-admin/list" element={ <Sidebar> <SubAdminList /> </Sidebar> } />
          <Route path="/sub-admin/addeditdata" element={ <Sidebar> <SubAdminAddEditData /> </Sidebar> } />
          
          
          <Route path="/coin/list" element={ <Sidebar> <Coin /> </Sidebar> } />
          <Route path="/coin/addEditData" element={ <Sidebar> <AddEditCoin /> </Sidebar> } />

          <Route path="/users/list" element={ <Sidebar> <UsersList /> </Sidebar> } />
          <Route path="/users/addeditdata" element={ <Sidebar> <AddEditUsers /> </Sidebar> } />
          
          <Route path="/request/list" element={ <Sidebar> <RequestList /> </Sidebar> } />

          {/* END */}
        </Routes>
      
    </div>
  );
};

export default App;
