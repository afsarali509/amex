import React, { useEffect, useState, useRef } from "react";
import {notification} from 'antd';
import {
  InfoCircleOutlined,
  CheckCircleOutlined,
  ArrowLeftOutlined,
} from "@ant-design/icons";
import { Link, useLocation, useNavigate } from "react-router-dom";
import LoadingEffect from "../../../components/Loading/LoadingEffect";
import {addEditUsers}  from  "../../../controllers/V1/usersController";
const UserListEditPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const state = location?.state;
  console.log('state : ', state);
  const [error, setError] = useState([]);
  const [ADDEDITDATA, setAddEditSata] = useState(state || {} );
  const [isLoading, setIsLoading] = useState(false);
  const [loadingText, setLoadingText] = useState('Loading, please wait...');
 
  //End


  /*********************************************************
   *  This function is use to handle imput chnage
   *********************************************************/
  const handleChange = (e) => {
    setAddEditSata((pre) => ({
      ...pre,
      [e.target.name]: e.target.value,
    }));
    setError((pre) => ({
      ...pre,
      [e.target.name]: "",
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData(e.target);
      console.log('email : ', formData.get('email'));
      if(!formData.get('name')){
        notification.open({
            message: "Oops!",
            description: `Name is required`,
            placement: "topRight",
            icon: <InfoCircleOutlined style={{ color: "red" }} />,
            duration: 2,
          });
      } else if(!formData.get('editId') && !formData.get('email')){
          notification.open({
            message: "Oops!",
            description: `Email is required`,
            placement: "topRight",
            icon: <InfoCircleOutlined style={{ color: "red" }} />,
            duration: 2,
          });
      } else if (!formData.get('editId') && !formData.get('phone')){
          notification.open({
            message: "Oops!",
            description: `Phone is required`,
            placement: "topRight",
            icon: <InfoCircleOutlined style={{ color: "red" }} />,
            duration: 2,
          });
      } else if (!formData.get('password') && !formData.get('editId')){
          notification.open({
            message: "Oops!",
            description: `Password is required`,
            placement: "topRight",
            icon: <InfoCircleOutlined style={{ color: "red" }} />,
            duration: 2,
          });
      } else if (formData.get('password') && formData.get('password') !== formData.get('confirm_password')){
          notification.open({
            message: "Oops!",
            description: `Password and confirm password not match`,
            placement: "topRight",
            icon: <InfoCircleOutlined style={{ color: "red" }} />,
            duration: 2,
          });
      } else {
        const param = {
          name : formData.get('name'),
          ...(formData.get('editId') && {editId : formData.get('editId')}),
          ...(formData.get('password') && {password : formData.get('password')}),
          // ...(!formData.get('editId') && {email : formData.get('email')}),
          // ...(!formData.get('editId') && {phone : formData.get('phone')}),
          email : formData.get('email') || ADDEDITDATA?.email,
          phone : formData.get('phone') || ADDEDITDATA?.phone
        }
        const res = await addEditUsers(param);
        if(res.status === true){
          notification.open({
            message: "Oops!",
            description: `Coin added successfully`,
            placement: "topRight",
            icon: < CheckCircleOutlined style={{ color: "green" }} />,
            duration: 2,
          });
          navigate('/users/list');
        } else {
          notification.open({
            message: "Oops!",
            description: `${res?.message}`,
            placement: "topRight",
            icon: <InfoCircleOutlined style={{ color: "red" }} />,
            duration: 2,
          });
        }
      }
    } catch (error) {
      console.log('error : ', error);
    }
  }



  useEffect(() => {
    document.title = `AMEX || ${ADDEDITDATA?.id ? "Edit" : "Add"
      } Invoice`;
  }, []);

  
  return (
    <div>
      {" "}
      <div className="container-fluid">
        <div className="Inventory_edit_page_main_div">
          <React.Fragment>
            <h5 className="inventory_edit_page_heading"> {`${ADDEDITDATA?.id ? "Edit" : "Add"} User`} </h5>
          </React.Fragment>
          <Link to="/users/list">
            <React.Fragment>
              <button type="button" className="btn btn-secondary"> <ArrowLeftOutlined /> Back </button>
            </React.Fragment>
          </Link>
        </div>

        <div className="card shadow mb-4 dataBase_table_Add_Data">
          <div className="card-body">
            <div className="responsive">
              <form method="post" className="inventory_form_main_contnet" onSubmit={handleSubmit} >
                <input type="hidden" name="editId" id="editId" value={ADDEDITDATA?.id} />
                <div className="row ">
                  <div className="row">

                    <div className="form-group col-lg-4 col-md-4 col-sm-6 col-xs-12 vendor_Add_edit_data">
                      <label
                        htmlFor="name"
                        className="all_section_for_label_main_class"
                      >
                        <span style={{ color: "red" }}>*</span>Name :{" "}
                      </label>
                      <input
                        type="text"
                        name="name"
                        className="form-control store_input_field"
                        id="name"
                        value={ADDEDITDATA?.name}
                        onChange={handleChange}
                      />
                      {error.coin ? (
                        <p style={{ color: "red" }}>{error.coin}</p>
                      ) : (
                        ""
                      )}
                    </div>

                    <div className="form-group col-lg-4 col-md-4 col-sm-6 col-xs-12 vendor_Add_edit_data">
                      <label
                        htmlFor="email"
                        className="all_section_for_label_main_class"
                      >
                        <span style={{ color: "red" }}>*</span>Email :{" "}
                      </label>
                      <input
                        type="email"
                        name="email"
                        className="form-control store_input_field"
                        id="email"
                        disabled={ADDEDITDATA?.id ? true : false}
                        value={ADDEDITDATA?.email}
                        onChange={handleChange}
                      />
                      {error.email ? (
                        <p style={{ color: "red" }}>{error.email}</p>
                      ) : (
                        ""
                      )}
                    </div>

                    <div className="form-group col-lg-4 col-md-4 col-sm-6 col-xs-12 vendor_Add_edit_data">
                      <label
                        htmlFor="phone"
                        className="all_section_for_label_main_class"
                      >
                        <span style={{ color: "red" }}>*</span>Phone :{" "}
                      </label>
                      <input
                        type="number"
                        name="phone"
                        className="form-control store_input_field"
                        id="phone"
                        disabled={ADDEDITDATA?.id ? true : false}
                        value={ADDEDITDATA?.phone}
                        onChange={handleChange}
                      />
                      {error.phone ? (
                        <p style={{ color: "red" }}>{error.phone}</p>
                      ) : (
                        ""
                      )}
                    </div>
                    {/* {!ADDEDITDATA?.id && (<> */}
                      <div className="form-group col-lg-4 col-md-4 col-sm-6 col-xs-12 vendor_Add_edit_data">
                        <label
                          htmlFor="password"
                          className="all_section_for_label_main_class"
                        >
                          <span style={{ color: "red" }}>*</span>Password :{" "}
                        </label>
                        <input
                          type="password"
                          name="password"
                          className="form-control store_input_field"
                          id="password"
                          onChange={handleChange}
                        />
                        {error.password ? (
                          <p style={{ color: "red" }}>{error.password}</p>
                        ) : (
                          ""
                        )}
                      </div>

                      <div className="form-group col-lg-4 col-md-4 col-sm-6 col-xs-12 vendor_Add_edit_data">
                        <label
                          htmlFor="confirm_password"
                          className="all_section_for_label_main_class"
                        >
                          <span style={{ color: "red" }}>*</span>Confirm password :{" "}
                        </label>
                        <input
                          type="password"
                          name="confirm_password"
                          className="form-control store_input_field"
                          id="confirm_password"
                          value={ADDEDITDATA?.confirm_password}
                          onChange={handleChange}
                        />
                        {error.confirm_password ? (
                          <p style={{ color: "red" }}>{error.confirm_password}</p>
                        ) : (
                          ""
                        )}
                      </div>
                    {/* </>)} */}

                  </div>
                </div>

                <div className="inventory_edit_submit_btn">
                  <button type="submit" className="btn btn-primary inventory_save_button" > Submit </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      
      </div>
      <LoadingEffect isLoading={isLoading} text={loadingText} />
    </div>
  );
};

export default UserListEditPage;
