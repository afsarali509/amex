import React, { useEffect, useState, useRef } from "react";
import {notification} from 'antd';
import {
  InfoCircleOutlined,
  CheckCircleOutlined,
  ArrowLeftOutlined,
} from "@ant-design/icons";
import { Link, useLocation, useNavigate } from "react-router-dom";
import LoadingEffect from "../../../components/Loading/LoadingEffect";
import {addEditCoin}  from  "../../../controllers/V1/coinsController";
const UserListEditPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const state = location?.state;
  console.log('state : ', state);
  const [error, setError] = useState([]);
  const [ADDEDITDATA, setAddEditSata] = useState(state || {} );
  const [isLoading, setIsLoading] = useState(false);
  const [loadingText, setLoadingText] = useState('Loading, please wait...');
 
  //End


  /*********************************************************
   *  This function is use to handle imput chnage
   *********************************************************/
  const handleChange = (e) => {
    setAddEditSata((pre) => ({
      ...pre,
      [e.target.name]: e.target.value,
    }));
    setError((pre) => ({
      ...pre,
      [e.target.name]: "",
    }));
  };

  const handleSUbmit = async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData(e.target);
      if(!formData.get('coin')){
        notification.open({
            message: "Oops!",
            description: `Coin is required`,
            placement: "topRight",
            icon: <InfoCircleOutlined style={{ color: "red" }} />,
            duration: 2,
          });
      } else if(!formData.get('symbol')){
          notification.open({
            message: "Oops!",
            description: `Symbol is required`,
            placement: "topRight",
            icon: <InfoCircleOutlined style={{ color: "red" }} />,
            duration: 2,
          });
      } else if (!formData.get('coin_id')){
          notification.open({
            message: "Oops!",
            description: `Coin Id is required`,
            placement: "topRight",
            icon: <InfoCircleOutlined style={{ color: "red" }} />,
            duration: 2,
          });
      } else {
        const param = {
          ...(formData.get('editId') && {editId : formData.get('editId')}),
          coin : formData.get('coin'),
          symbol : formData.get('symbol'),
          coin_id : formData.get('coin_id')
        }
        const res = await addEditCoin(param);
        if(res.status === true){
          notification.open({
            message: "Oops!",
            description: `Coin added successfully`,
            placement: "topRight",
            icon: < CheckCircleOutlined style={{ color: "green" }} />,
            duration: 2,
          });
          navigate('/coin/list');
        } else {
          notification.open({
            message: "Oops!",
            description: `${res?.message}`,
            placement: "topRight",
            icon: <InfoCircleOutlined style={{ color: "red" }} />,
            duration: 2,
          });
        }
      }
    } catch (error) {
      console.log('error : ', error);
    }
  }



  useEffect(() => {
    document.title = `AMEX || ${ADDEDITDATA?._id ? "Edit" : "Add"
      } Invoice`;
  }, []);

  
  return (
    <div>
      {" "}
      <div className="container-fluid">
        <div className="Inventory_edit_page_main_div">
          <React.Fragment>
            <h5 className="inventory_edit_page_heading"> Add/Edit Coin </h5>
          </React.Fragment>
          <Link to="/coin/list">
            <React.Fragment>
              <button type="button" className="btn btn-secondary"> <ArrowLeftOutlined /> Back </button>
            </React.Fragment>
          </Link>
        </div>

        <div className="card shadow mb-4 dataBase_table_Add_Data">
          <div className="card-body">
            <div className="responsive">
              <form method="post" className="inventory_form_main_contnet" onSubmit={handleSUbmit} >
                <input type="hidden" name="editId" id="editId" value={ADDEDITDATA?.id} />
                <div className="row ">
                  <div className="row">

                    <div className="form-group col-lg-4 col-md-4 col-sm-6 col-xs-12 vendor_Add_edit_data">
                      <label
                        htmlFor="coin"
                        className="all_section_for_label_main_class"
                      >
                        <span style={{ color: "red" }}>*</span>Coin :{" "}
                      </label>
                      <input
                        type="text"
                        name="coin"
                        className="form-control store_input_field"
                        id="coin"
                        value={ADDEDITDATA?.coin}
                        onChange={handleChange}
                      />
                      {error.coin ? (
                        <p style={{ color: "red" }}>{error.coin}</p>
                      ) : (
                        ""
                      )}
                    </div>

                    <div className="form-group col-lg-4 col-md-4 col-sm-6 col-xs-12 vendor_Add_edit_data">
                      <label
                        htmlFor="symbol"
                        className="all_section_for_label_main_class"
                      >
                        <span style={{ color: "red" }}>*</span>Symbol :{" "}
                      </label>
                      <input
                        type="text"
                        name="symbol"
                        className="form-control store_input_field"
                        id="symbol"
                        value={ADDEDITDATA?.symbol}
                        onChange={handleChange}
                      />
                      {error.symbol ? (
                        <p style={{ color: "red" }}>{error.symbol}</p>
                      ) : (
                        ""
                      )}
                    </div>

                    <div className="form-group col-lg-4 col-md-4 col-sm-6 col-xs-12 vendor_Add_edit_data">
                      <label
                        htmlFor="coin_id"
                        className="all_section_for_label_main_class"
                      >
                        <span style={{ color: "red" }}>*</span>Coin ID :{" "}
                      </label>
                      <input
                        type="text"
                        name="coin_id"
                        className="form-control store_input_field"
                        id="coin_id"
                        value={ADDEDITDATA?.coin_id}
                        onChange={handleChange}
                      />
                      {error.coin_id ? (
                        <p style={{ color: "red" }}>{error.coin_id}</p>
                      ) : (
                        ""
                      )}
                    </div>

                    

                  </div>
                </div>

                <div className="inventory_edit_submit_btn">
                  <button type="submit" className="btn btn-primary inventory_save_button" > Submit </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      
      </div>
      <LoadingEffect isLoading={isLoading} text={loadingText} />
    </div>
  );
};

export default UserListEditPage;
