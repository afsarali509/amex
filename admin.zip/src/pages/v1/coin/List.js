import React, { useEffect, useState, useRef } from "react";
import PropTypes from "prop-types";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import { Dropdown, Menu, notification, Drawer, Button, Space } from "antd";
import { faFilter, faEye, faTrash, faEdit, faThumbsUp, faThumbsDown } from '@fortawesome/free-solid-svg-icons';
import Pagination from "@mui/material/Pagination";

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEllipsis } from '@fortawesome/free-solid-svg-icons';

import TobNavBar from "../../DashBaord/Top_navbar";

import { Link, useNavigate } from "react-router-dom";

import {
  InfoCircleOutlined,
  CheckCircleOutlined,
} from "@ant-design/icons";

import moment from "moment";
import SkeltonList from "../../../components/SkeltonEffect/list";
import {
  list,
  coinChangeStatus
} from "../../../controllers/V1/coinsController";
import { getPage, getRelativeTime } from "../../../controllers/common";

function VendorList(props) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

VendorList.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

export default function BasicTabs() {
  const [isFilterShow, setFilterShow] = useState(false);
  const handleFilterDrawer = () =>  setFilterShow(!isFilterShow); 

  const [value, setValue] = React.useState(0);
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const [helpText, setHelpText] = useState('');

  /************************************************************************************* */
  const [isLoading, setIsLoading] =useState(true);
  const navigate = useNavigate();
  const targetRef = useRef(null);
  const inputRef1 = useRef(null);
  const inputRef2 = useRef(null);
  const inputRef3 = useRef(null);
  const inputRef4 = useRef(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [ALLLISTDATA, setListData] = useState([]);
  const [TOTALPAGES, setTotalPages] = useState(1);
  const [LIMIT, setLimit] = useState(10);
  const [SKIP, setSkip] = useState(0);
  const [filter, setFilter] = useState({
    from: "",
    to: "",
    filter_by: "",
    search: "",
  }); //End

  const [showRequest, setShowRequest] = useState("");

  const handleEdit = async (item = {}) => {
    navigate("/coin/addEditData", { state: item });
  };
  /*********************************************************
   *  This function is use to fetch vendor list
   *********************************************************/
  const getList = async () => {
    try {
      setIsLoading(true);
      setListData([]);

      const options = {
        type: "",
        condition: {
          ...(filter.filter_by === 'coin'?{ coin : filter?.search }:null),
          ...(filter.filter_by === 'symbol'?{symbol : filter?.search }:null),
          ...(filter.filter_by === 'coin_id'?{ coin_id : filter?.search }:null),
          
          ...(filter.filter_by === 'status'?{status : filter?.search }:null),
          ...(showRequest ? { status: showRequest } : null),
        },
        // select: [],
        skip: SKIP ? SKIP : 0,
        limit: LIMIT ? LIMIT : 10,
      };
      const listData = await list(options);
      if (listData.status === true) {
        if (listData.result.length > 0) {
          setListData(listData?.result);
          setTotalPages(getPage(listData?.count))
        } else {
          setListData([]);
          setTotalPages(getPage(1))
        }
      } else {
        setListData([]);
      }
      setIsLoading(false);
    } catch (error) {
      setIsLoading(false);
    }
  }; //End

  /*********************************************************
   *  This function is for handle page change
   *********************************************************/
  const handlePageChange = (event, newPage) => {
    setCurrentPage(newPage);
    setSkip((newPage - 1) * LIMIT);
    targetRef.current.scrollIntoView({
      behavior: "smooth",
    });
  };
 

  /*********************************************************
   *  This function is use to handle remove invoice
   *********************************************************/
  const handleChangeStatus = async (id='', status='') => {
    try {
      if(!id){
        notification.open({
          message: "Oops!",
          description: `Id is required.`,
          placement: "topRight",
          icon: <InfoCircleOutlined style={{ color: "red" }} />,
          duration: 2,
        });
      } else if(!status && status === ''){
        notification.open({
          message: "Oops!",
          description: `Status is required.`,
          placement: "topRight",
          icon: <InfoCircleOutlined style={{ color: "red" }} />,
          duration: 2,
        });
      } else{
        const option = {
            coin_id : parseInt(id),
            status : status
        }
        const res = await coinChangeStatus(option);
        if (res.status === true) {
          notification.open({
            message: "Success",
            description: `Status changed successfully.`,
            placement: "topRight",
            icon: <CheckCircleOutlined style={{ color: "green" }} />,
            duration: 2,
          });
        } else {
          notification.open({
            message: "Oops!",
            description: `${res?.message}`,
            placement: "topRight",
            icon: <InfoCircleOutlined style={{ color: "red" }} />,
            duration: 2,
          });
        }
      }
    } catch (error) {
      notification.open({
        message: "Oops!",
        description: `Operation not perform yet! please try in some time.`,
        placement: "topRight",
        icon: <InfoCircleOutlined style={{ color: "red" }} />,
        duration: 2,
      });
    }
    getList();
  };

 
  
  const dropdownMenu = (items) => {
    return (
      <>
        <Menu>
          <Menu.Item key="01" onClick={()=>handleEdit(items)}>
            <FontAwesomeIcon icon={faEdit} />
            <span className="show_span_edit">Edit</span>
          </Menu.Item>
          {items?.status === 'A' ? (
            <Menu.Item key={`02`} onClick={() => { handleChangeStatus(items.id, 'I'); }} >
              <FontAwesomeIcon icon={faThumbsDown} /> <span className="show_span">Inactive</span>
            </Menu.Item>
          ):(
            <Menu.Item key={`02`} onClick={() => { handleChangeStatus(items.id, 'A'); }} >
              <FontAwesomeIcon icon={faThumbsUp} /> <span className="show_span">Active</span>
            </Menu.Item>
          )}
        </Menu>
      </>
    );
  };

  /*********************************************************
   *  This function is ued for handle filter input change
   *********************************************************/
  const handleFilterReset = () => {
    try {
      setFilter('');
      inputRef1.current.value = '';
      inputRef2.current.value = '';
      inputRef3.current.value = '';
      inputRef4.current.value = '';
    } catch (error) {
      
    }
  }

  const handleFilterApply = (e) => {
    try {
      e.preventDefault();
      const form = new FormData(e.target);
      setFilter((pre)=>({
        ...pre,
        'filter_by' : form.get('filter_by') || '',
        'search'    : form.get('search') || '',
        'to'        : form.get('to_date') || '',
        'from'      : form.get('from_date') || '',

      }))
      handleFilterDrawer();
      setSkip(0);
    } catch (error) {
      
    }
  }

  /*********************************************************
   *  This function will load when page load and with dependency update
   *********************************************************/
  useEffect(() => {
    getList();
    targetRef.current.scrollIntoView({
      behavior:'smooth',
    });
    document.title = "AMEX || Request List";
  }, [currentPage, showRequest, filter]);

  return (
    <>
      <div className="container-fluid" ref={targetRef}>
        <TobNavBar title={"Coin List"}></TobNavBar>
        <div className="inventory_tabs_main_div">
          <Box sx={{ width: "100%" }}>
            <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
              <div className="inventory_all_tabs">
                <div className="all_tabs_value">
                  <Tabs
                    value={value}
                    onChange={handleChange}
                    aria-label="basic tabs example"
                    className="item_tabs_main_container"
                  >
                    <Tab
                      label="All"
                      className="tabs_main_contnet"
                      {...a11yProps(0)}
                      onClick={() => setShowRequest("")}
                    />
                  </Tabs>
                </div>

                <div className="fa_filter_rating_review filter_img_and_add_btn_main">
                  <div className="inventory_filter_div" onClick={handleFilterDrawer}>
                  <FontAwesomeIcon icon={faFilter} />
                    <Link
                      to={false}
                      className="filter_btn_invontry_rating_review"
                    >
                      Filters
                    </Link>
                  </div>
                  <div onClick={() => handleEdit()}>
                    <button type="button" class="btn btn-dark">
                    <FontAwesomeIcon icon="fa-light fa-plus Promotions_faPlus_Squares" />
                   
                      <span className="request_new_categories">Add New</span>
                    </button>
                  </div>
                </div>
              </div>
            </Box>            
            <VendorList 
              >
              <div>
                <div id="content-wrapper" className="d-flex flex-column">
                  <div className="card shadow mb-4">
                    <div className="card-body pt-0">
                      <div className="table-responsive">
                        <table
                          className="table table-bordered"
                          id="dataTable"
                          width="100%"
                          cellspacing="0"
                        >
                          <thead>
                            <tr>
                              <th>Sl. No.</th>
                              <th>Coin</th>
                              <th>Symbol</th>
                              <th>Coin Id</th>
                              <th>Status</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            {ALLLISTDATA?.length > 0 ? (
                              ALLLISTDATA.map((items, index) => (
                                <>
                                  <tr key={index}>
                                    <td>{index + SKIP + 1}</td>
                                    <td>{items?.coin}</td>
                                    <td>{items?.symbol}</td>
                                    <td>{items?.coin_id}</td>
                                    <td className="admin_user_list_date">{items?.status}</td>
                                    <td>
                                      <Dropdown
                                        overlay={() => dropdownMenu(items)}
                                        placement="bottomLeft"
                                        arrow
                                      >
                                          <FontAwesomeIcon icon={faEllipsis} />
                                      </Dropdown>
                                    </td>
                                  </tr>
                                </>
                              ))
                            ) : isLoading ? <SkeltonList row={10} col={6} /> : <tr> 
                                <td colspan="9" className="img-center" >No data found !</td> 
                            </tr>}
                          </tbody>
                        </table>
                        <div className="table_pagination_sales_order">
                          <Pagination
                            count={TOTALPAGES}
                            onChange={handlePageChange}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </VendorList>
          </Box>
        </div>
      </div>
      {/* Filter */}
      <Drawer
        title="Filter"
        placement={`right`}
        width={500}
        onClose={handleFilterDrawer}
        open={isFilterShow}
        extra={
          <Space>
            <Button onClick={handleFilterDrawer}>Cancel</Button>
            <Button type="primary" onClick={handleFilterReset}  style={{ backgroundColor: 'red', color: 'white' }}>
              Reset
            </Button>
          </Space>
        }
      >
        <div className="responsive">
          <div className="row">
            <form id='filter_form' onSubmit={handleFilterApply}>
              <div className="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <label htmlFor="filter_by" className="all_section_for_label_main_class" >
                  Search Field :
                </label>
                <select name="filter_by" className="form-control store_input_field" id="filter_by" ref={inputRef1}>
                  <option value=''>Select search field</option>
                  <option value='coin' selected={filter?.filter_by ==='coin'?true:false}>Coin</option>
                  <option value='symbol' selected={filter?.filter_by ==='symbol'?true:false}>Symbol</option>
                  <option value='coin_id' selected={filter?.filter_by ==='coin_id'?true:false}>Coin Id</option>
                  <option value='status' selected={filter?.filter_by ==='status'?true:false}>Status</option>
                </select>
              </div>
              <div className="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <label htmlFor="search" className="all_section_for_label_main_class" >
                  Search Text :
                </label>
                <input
                  title="Enter search text."
                  placeholder="Enter search text."
                  type="text"
                  name="search"
                  className="form-control store_input_field"
                  id="search"  
                  ref={inputRef2}
                />
                {helpText?<label style={{color:'blue'}}>{helpText}</label>:''}
              </div>
              
              <br/>
              <div className="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <button
                  title="Enter search text."
                  type="submit"
                  className="form-control btn btn-black"    
                  style={{ backgroundColor: "black", color: "white" }}           
                >Apply</button>
              </div>
            </form>
          </div>
        </div>
      </Drawer>
    </>
  );
}
