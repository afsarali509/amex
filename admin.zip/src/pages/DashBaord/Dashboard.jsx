import "./main_dashboard.css";
import Top_navbar from "./Top_navbar";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCreditCard } from '@fortawesome/free-regular-svg-icons';

// import * as XLSX from 'xlsx';
import { useNavigate } from "react-router-dom";

const Dashboard = () => {
 const navigate = useNavigate();
  
  return (
    <>
      <Top_navbar></Top_navbar>
      <div className="container-fluid">
        <div className="row">

          <div className="col-md-3 px-0" onClick={()=>navigate('/users/list')}>
            <div className="transaction_form">
              <div className="transaction_Card margin-right">
                <span style={{marginLeft:'10px',marginRight:'10px'}}>  <FontAwesomeIcon icon={faCreditCard} className="sidebar_collapse_iohomeoutline" /></span>
                <div className="transction_main_Card ">
                  <h1 className="dashboard_top_heading_user"> User's List</h1>
                </div>
                <p className="presentation my-2">
                  Navigate to user's list
                </p>
              </div>
            </div>
          </div>

          <div className="col-md-3 px-0"onClick={()=>navigate('/coin/list')}>
            <div className="transaction_form">
              <div className="transaction_Card margin-right">
                <span style={{marginLeft:'10px',marginRight:'10px'}}>  <FontAwesomeIcon icon={faCreditCard} className="sidebar_collapse_iohomeoutline" /></span>
                <div className="transction_main_Card ">
                  <h1 className="dashboard_top_heading_user"> Coin's List</h1>
                </div>
                <p className="presentation my-2">
                  Navigate to bulk coin's list
                </p>
              </div>
            </div>
          </div>

          {/* <div className="col-md-3 px-0"onClick={()=>navigate('/transaction')}>
            <div className="transaction_form">
              <div className="transaction_Card margin-right">
                <span style={{marginLeft:'10px',marginRight:'10px'}}>  <FontAwesomeIcon icon={faCreditCard} className="sidebar_collapse_iohomeoutline" /></span>
                <div className="transction_main_Card ">
                  <h1 className="dashboard_top_heading_user"> Transaction</h1>
                </div>
                <p className="presentation my-2">
                  Navigate to bulk invoice request list
                </p>
              </div>
            </div>
          </div> */}
          
        </div>
      
      </div>
    </>
  );
};

export default Dashboard;
