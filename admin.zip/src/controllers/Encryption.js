const SECRET_KEY = "asqsdeasdfdwjkhfgjkdjhsfhksbkdfg"; // 32 character की key होनी चाहिए
const ENCODER = new TextEncoder();
const DECODER = new TextDecoder();

// **Key Generate Function**
const getKey = async () => {
  return crypto.subtle.importKey(
    "raw",
    ENCODER.encode(SECRET_KEY),
    { name: "AES-GCM" },
    false,
    ["encrypt", "decrypt"]
  );
};

// **Encrypt Function**
export const encryptData = async (text) => {
  const key = await getKey();
  const iv = crypto.getRandomValues(new Uint8Array(12)); // Random IV
  const encrypted = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    ENCODER.encode(text)
  );

  return {
    iv: Array.from(iv), // IV को साथ भेजना ज़रूरी है
    data: Array.from(new Uint8Array(encrypted))
  };
};

// **Decrypt Function**
export const decryptData = async (encryptedObj) => {
  try {
    const key = await getKey();
    const { iv, data } = encryptedObj;
    const decrypted = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: new Uint8Array(iv) },
      key,
      new Uint8Array(data)
    );
  
    return DECODER.decode(decrypted);
    
  } catch (error) {
    console.log('dec error  : ', error);
  }
};

// // **Example Usage**
// (async () => {
//   const encrypted = await encryptData("Hello, Secure World!");
//   console.log("Encrypted:", encrypted);

//   const decrypted = await decryptData(encrypted);
//   console.log("Decrypted:", decrypted);
// })();
